﻿using UnityEditor;
using UnityEngine;

namespace Wooget.Wooga.SDK.Logging.Editor {
   public class LogEditorScript
    {

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Error", false, 1)]
        static void SetError()
        {
            Log.MinSeverity = Logging.SeverityId.Error;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Warning", false, 2)]
        static void SetWarning()
        {
            Log.MinSeverity = Logging.SeverityId.Warning;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Info", false, 3)]
        static void SetInfo()
        {
            Log.MinSeverity = Logging.SeverityId.Info;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Debug", false, 4)]
        static void SetDebug()
        {
            Log.MinSeverity = Logging.SeverityId.Debug;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Silent", false, 51)]
        static void SetSilent()
        {
            Log.MinSeverity = Logging.SeverityId.Silent;
        }
        
        [MenuItem("Wooga/WDK/Logging/Enable Colored Log",false, 101)]
        static void EnableColorLog()
        {
            Log.UseColor = true;
        }
        
        [MenuItem("Wooga/WDK/Logging/Disable Colored Log",false, 102)]
        static void DisableColorLog()
        {
            Log.UseColor = false;
        }

        
#region Validation Methods
        
        [MenuItem("Wooga/WDK/Logging/Disable Colored Log",true)]
        static bool ValidateDisableColorLog()
        {
            return Log.UseColor == true && Application.isPlaying;
        }
        
                
        [MenuItem("Wooga/WDK/Logging/Enable Colored Log", true)]
        static bool ValidateEnableColorLog()
        {
            return Log.UseColor == false && Application.isPlaying;
        }
        
 
        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Error", true)]
        static bool ValidateError()
        {
            return Log.MinSeverity != Logging.SeverityId.Error && Application.isPlaying;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Silent", true)]
        static bool ValidateSilent()
        {
            return Log.MinSeverity != Logging.SeverityId.Silent && Application.isPlaying;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Warning", true)]
        static bool ValidateWarning()
        {
            return Log.MinSeverity != Logging.SeverityId.Warning && Application.isPlaying;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Info", true)]
        static bool ValidateInfo()
        {
            return Log.MinSeverity != Logging.SeverityId.Info && Application.isPlaying;
        }

        [MenuItem("Wooga/WDK/Logging/Set Logging Level/Debug", true)]
        static bool ValidateDebug()
        {
            return Log.MinSeverity != Logging.SeverityId.Debug && Application.isPlaying;
        }
#endregion
    }
}


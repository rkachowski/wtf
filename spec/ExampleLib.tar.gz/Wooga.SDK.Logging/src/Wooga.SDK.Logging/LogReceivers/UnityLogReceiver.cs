﻿namespace Wooget.Wooga.SDK.Logging
{
    public static class UnityLogReceiver
    {

        public static void Log(string message, SeverityId severity)
        {
#if UNITY_EDITOR || UNITY_IOS || UNITY_IPHONE || UNITY_ANDROID

            if (severity >= Logging.Log.MinSeverity)
            {
                switch (severity)
                {
                    case SeverityId.Warning:
                        UnityEngine.Debug.LogWarning(message);
                        break;
                    case SeverityId.Error:
                        UnityEngine.Debug.LogError(message);
                        break;
                    default:
                        UnityEngine.Debug.Log(message);
                        break;
                }
            }
#elif DEBUG
            System.Console.WriteLine(message);
#endif
        }

    }
}

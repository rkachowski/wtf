//This file is generated on release
//The Wooga.SDK.Meta namespace is inspected by the tracking sdk at startup to detect which libs are in use

namespace Wooga.SDK.Meta
{
  static public class Wooga_SDK_Logging
  {
    public static readonly string name = "Wooga.SDK.Logging";
    public static readonly string version = "0.0.9";
  }
}
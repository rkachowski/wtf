### 0.0.9 - May 11 2016
* [FIX] Remove removed constants from editor script

### 0.0.8 - May 11 2016
* [FIX] Remove editorpref usages for thread safety issues

### 0.0.7 - April 25 2016
* [FIX] improve log on webgl platform

### 0.0.6 - April 25 2016
* [FIX] dont reflect on stackframe in il2cpp

### 0.0.5 - April 12 2016
* orange log
### 0.0.4 - 07 April 2016
* Binary package

### 0.0.3 - 07 April 2016
* Editor menu

### 0.0.2 - 07 April 2016
* Template + namespace fix

### 0.0.1 - 06 April 2016
* initial release

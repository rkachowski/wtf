using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using First.Others.Dont.Matter;
using Wooget.Wooga.SDK.Logging;
using NUnit.Framework;
using Wooga.Wooget.SDK.Services.Wooga.TestNamespace.Wooga.Wooget;

namespace LogTests
{
    [TestFixture]
    public class Tests
    {
        [Test]
        public void TestRetrieveSDKFromString()
        {
            Assert.AreEqual("Tracking", Log.SDKNameFromNamespace("Wooga.Tracking"));
            Assert.AreEqual("Logging", Log.SDKNameFromNamespace("Wooget.Wooga.SDK.Logging"));
            Assert.AreEqual("ErrorAnalytics", Log.SDKNameFromNamespace("Wooga.Services.ErrorAnalytics"));
            Assert.AreEqual("InAppPurchase", Log.SDKNameFromNamespace("Wooga.Services.InAppPurchase.Integration.Sbs"));

        }

        [Test]
        public void TestRetrieveSDKFromStackFrame()
        {
            //This looks weird because it is taking the value directly from the execution stack
            //what is important is that the invoking method is in a different namespace
            TestClass.CallSomething(() =>
            {
                var frame = new StackFrame(1);
                Assert.AreEqual("TestNamespace", Log.SDKNameFromFrame(frame));
            });

            TestClass2.CallSomething(() =>
            {
                var frame = new StackFrame(1);
                Assert.AreEqual("First", Log.SDKNameFromFrame(frame));
            });
        }
    }
}

namespace Wooga.Wooget.SDK.Services.Wooga.TestNamespace.Wooga.Wooget
{
    public static class TestClass
    {
        public static void CallSomething(Action anAction)
        {
            anAction();
        }
    }
}


namespace First.Others.Dont.Matter
{
    public static class TestClass2
    {
        public static void CallSomething(Action anAction)
        {
            anAction();
        }
    }
}
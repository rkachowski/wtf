## Wooga.SDK.Logging

### Summary

SDK logging package, provides internal info

### Description

Provides a central means of logging internal events for debug purposes. Implements an observer style receiver mechanism to deal with custom log handling - uses `UnityLogReceiver` by default.

Comes with an editor script to customise log level as well as colorisation for output.


### Usage

```csharp
using Wooget.Wooga.SDK.Logging;

Log.Error("I'm an error");
Log.Warning("I'm a warning, there's also info and debug levels but you know this");

Log.OnLog += (string logMessage, SeverityId severity) => Debug.Log("I'm a stupid custom log handler! look at this " + logMessage);

Log.Info("I'm going to be sent to the custom log handler as well as whatever else is there!");

```

### Log Levels 

* Debug
> Intensely technical information. Parameters, constructed strings, checkpoints and info generally useful for debugging. Noisy.

* Info
> Normal but notable behaviour. Network requests, files written, important objects constructed. Less noisy.

* Warning
> Unexpected but recoverable behaviour. Handled exception, case defaults, correctly dealt with invalid data. Occasional

* Error
> Something very terrible occurred. Something is corrupted, required data can't be accessed, invariants are not held. This should never happen



﻿using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Wooget.Wooga.SDK.Logging
{
    public static class Log
    {
        private static List<LogHandler> __handlers = new List<LogHandler>();
        private static event LogHandler _OnLog;
        public static event LogHandler OnLog
        {
            add
            {
                _OnLog += value;
                __handlers.Add(value);
            }
            remove
            {
                _OnLog -= value;
                __handlers.Remove(value);
            }
        }


        public static SeverityId MinSeverity = SeverityId.Warning;
        public static bool UseColor = true;

        static Log()
        {
            OnLog += UnityLogReceiver.Log;
        }

        #region Public API
        public static void Error(string message)
        {
            HandleLog(message, SeverityId.Error);
        }

        public static void Warning(string message)
        {
            HandleLog(message, SeverityId.Warning);
        }

        public static void Info(string message)
        {
            HandleLog(message, SeverityId.Info);
        }

        public static void Debug(string message)
        {
            HandleLog(message, SeverityId.Debug);
        }

        public static void ClearListeners()
        {
            foreach (var handler in __handlers)
            {
                _OnLog -= handler;
            }

            __handlers.Clear();
        }
        #endregion

        static void HandleLog(string message, SeverityId severity)
        {
            if (_OnLog != null)
            {
                var logMessage = AssembleMessage(message, severity);
                _OnLog(logMessage, severity);
            }
        }

        private static string AssembleMessage(string message, SeverityId severity)
        {
#if UNITY_WEBGL
            return severity.ToString() + " " + message;
#endif
            var stackFrame = new StackFrame(3, true);
            var builder = new StringBuilder();
            var fileName = Path.GetFileName(stackFrame.GetFileName());

#if UNITY_EDITOR
            if(UseColor)
                ColorLog(builder,stackFrame,fileName);
            else
                StandardLog(builder,stackFrame,fileName);
#else
            StandardLog(builder, stackFrame, fileName);
#endif
            builder.Append(" " + severity.ToString().ToUpper() + " ");
            builder.Append(message);

            return builder.ToString();
        }

#if UNITY_EDITOR

        private static void ColorLog(StringBuilder builder, StackFrame stackFrame, string fileName)
        {
            var sdkName = SDKNameFromFrame(stackFrame);
            if (sdkName.Length > 0)
            {
                builder.Append("<color=orange>[" + SDKNameFromFrame(stackFrame) + "]</color> ");
            }
            builder.Append("<color=white>");
            builder.Append(fileName + ":" + stackFrame.GetFileLineNumber());
            builder.Append("</color> ");
        }

#endif

        private static void StandardLog(StringBuilder builder, StackFrame stackFrame, string fileName)
        {
            //il2cpp will give us no meaningful info from the stackFrame (and will throw a null expection when working with it)
            //so we exclude 
#if !UNITY_IOS || UNITY_EDITOR
            var sdkName = SDKNameFromFrame(stackFrame);
            if (sdkName.Length > 0)
            {
                builder.Append("[" + SDKNameFromFrame(stackFrame) + "] ");
            }
#endif

            builder.Append(fileName + ":" + stackFrame.GetFileLineNumber());
            builder.Append(" ");
        }

        /// <summary>
        /// Get the sdk that invoked the log from the provided stack frame
        /// 
        /// For logging purposes, the sdk is considered to be the first word in a namespace that is not in a
        /// collection of blacklisted words
        /// </summary>
        /// <param name="stackFrame">The frame where log was invoked</param>
        /// <returns>String to identify calling package</returns>
        public static string SDKNameFromFrame(StackFrame stackFrame)
        {
            var klass = stackFrame.GetMethod().ReflectedType;
            return SDKNameFromNamespace(klass.Namespace);
        }

        private static readonly string[] ReservedWords = new string[] { "Wooga", "Wooget", "Services", "Unity3D", "SDK" };
        public static string SDKNameFromNamespace(string namespace_)
        {
            var sb = new StringBuilder(namespace_);

            foreach (var word in ReservedWords)
            {
                sb.Replace(word, "");
            }

            var matches = Regex.Matches(sb.ToString(), @"\.*(\w+)\.*?");
            return matches.Count > 0 ? matches[0].Groups[1].Value : "";
        }
    }
    public enum SeverityId
    {
        NotSet = 0,
        /// <summary>
        /// Log everything
        /// </summary>
        Debug = 1,
        /// <summary>
        /// Log informational messages + warnings + errors
        /// </summary>
        Info,
        /// <summary>
        /// Log warning messages + errors
        /// </summary>
        Warning,
        /// <summary>
        ///  Log only errors
        /// </summary>
        Error,
        /// <summary>
        ///  Log nothing
        /// </summary>
        Silent
    }

    public delegate void LogHandler(string message, SeverityId severity);
}

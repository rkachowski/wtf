﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Wooga.Foundation.Tests
{
    public static class TestTools
    {
        public static string GetTempPath()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
			string tempPath = UnityEngine.Application.temporaryCachePath;
#else
            string tempPath = System.IO.Path.GetTempPath();
#endif
            return tempPath;
        }

        public static string CreateNewTemporaryDirectory()
        {
            string tempDirectory = Path.Combine(GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempDirectory);
            return tempDirectory;
        }
    }
}

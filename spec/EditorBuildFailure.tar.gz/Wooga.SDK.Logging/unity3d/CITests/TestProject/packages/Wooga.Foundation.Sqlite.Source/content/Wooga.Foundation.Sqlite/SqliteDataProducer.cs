﻿using System;
using Wooga.Lambda.Control.Concurrent;
using Wooga.Lambda.Control.Monad;
using Wooga.Lambda.Data;

namespace Wooga.Foundation.Sqlite
{
    public class SqliteStringProducer : Producer<string, string>
    {
        SQLiteConnection db;

        private AtomicCounter _availableCount;

        private AtomicCounter _consumingCount = new AtomicCounter();

        public SqliteStringProducer(string path, long maxDataSize = 1024)
        {
            try
            {
                OpenAndInitializeDatabase(path, maxDataSize);
            }
            catch
            {
                System.IO.File.Delete(path);
                OpenAndInitializeDatabase(path, maxDataSize);
            }
        }

        public void Close()
        {
            db.Close();
        }

        private void OpenAndInitializeDatabase(string path, long maxDataSize)
        {
            db = new SQLiteConnection(path, SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.FullMutex);
            db.Query<PersistedData>("create table if not exists \"PersistedData\"(\n\"Id\" integer primary key autoincrement not null ,\n\"Data\" varchar(" + maxDataSize + ") ,\n\"ModificationToken\" varchar(32) ,\n\"IsConsumed\" integer )");
            db.Query<PersistedData>("UPDATE PersistedData SET IsConsumed = 0");
            _availableCount = new AtomicCounter(db.Query<PersistedDataIdCount>("SELECT COUNT(Id) As IdCount FROM PersistedData")[0].IdCount);
        }

        public Async<Unit> Produce(string input)
        {
            return () =>
            {
                db.Insert(new PersistedData() { Data = input, ModificationToken = Guid.NewGuid().ToString(), IsConsumed = false });
                _availableCount.Increment();
                return Unit.Default;
            };
        }

        public Async<Maybe<TConsumed>> Consume<TConsumed>(Consumer<string, TConsumed> consumer)
        {
            return () =>
            {
                var dataToConsume = Maybe.Nothing<string>();
                var result = db.Query<PersistedData>("SELECT * FROM PersistedData WHERE IsConsumed = 0 LIMIT 1");
                PersistedData data = default(PersistedData);
                if (result.Count == 1)
                {
                    data = result[0];
                    var modificationMarker = Guid.NewGuid().ToString();
                    db.Query<PersistedData>(
                        "UPDATE PersistedData SET IsConsumed = 1, ModificationToken = ? WHERE IsConsumed = 0 AND Id = ?", modificationMarker, data.Id);

                    var validationResult =
                        db.Query<PersistedData>("SELECT * FROM PersistedData WHERE Id = ?", data.Id);
                    if (validationResult.Count == 1 && validationResult[0].ModificationToken == modificationMarker)
                    {
                        _availableCount.Decrement();
                        _consumingCount.Increment();
                        dataToConsume = Maybe.Just(data.Data);
                    }
                    else
                    {
                        // our CAS has failed so eagerly try to find something for consumption
                        return Consume(consumer).RunSynchronously();
                    }
                }

                return dataToConsume.Bind<string, TConsumed>(input =>
                {
                    try
                    {
                        var r = consumer(input).RunSynchronously();
                        if (r.IsJust())
                        {
                            db.Query<PersistedData>("DELETE FROM PersistedData WHERE Id = ?", data.Id);
                        }
                        else
                        {
                            db.Query<PersistedData>("UPDATE PersistedData SET IsConsumed = 0 WHERE Id = ?", data.Id);
                            _availableCount.Increment();
                        }
                        _consumingCount.Decrement();
                        return r;
                    }
                    catch (Exception)
                    {
                        db.Query<PersistedData>("UPDATE PersistedData SET IsConsumed = 0 WHERE Id = ?", data.Id);
                        _availableCount.Increment();
                        _consumingCount.Decrement();
                        return Maybe.Nothing<TConsumed>();
                    }
                });
            };
        }

        public bool HasMore()
        {
            return _availableCount.Count > 0;
        }

        public int AvailableCount()
        {
            return _availableCount.Count;
        }

        public bool IsBeingConsumed()
        {
            return _consumingCount.Count > 0;
        }
    }

    class PersistedData
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Data { get; set; }
        [MaxLength(32)]
        public string ModificationToken { get; set; }

        public bool IsConsumed { get; set; }
    }

    class PersistedDataIdCount
    {
        public int IdCount { get; set; }
    }

    class AtomicCounter
    {
        private int _count = 0;

        public AtomicCounter()
        {

        }

        public AtomicCounter(int count)
        {
            _count = count;
        }

        public int Count
        {
            get
            {
                lock (this)
                {
                    return _count;
                }
            }
        }

        public void Increment()
        {
            lock (this)
            {
                _count++;
            }
        }

        public void Decrement()
        {
            lock (this)
            {
                _count--;
            }
        }
    }
}

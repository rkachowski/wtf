# Foundation

Bundles some base functionality used by the WDK SDKs.

| Branch | Build Status |
|--------|--------------|
| master | [![Build Status](https://magnum.travis-ci.com/wooga/wdk-unity-Foundation.svg?token=XG5jEsLQaZxpndE6F3kH&branch=master)](https://magnum.travis-ci.com/wooga/wdk-unity-Foundation)|

[ApiDoc](http://ci.sdk.wooga.com:8080/job/wdk-unity-Foundation/ws/documentation/index.html)

## Wooga.Foundation.Collections



## Wooga.Foundation.Editor.Unity3D

Paket Integration for the unity editor. Adds menu items for the most common Paket tasks into the unity editor.

## Wooga.Foundation.IO

AtomicFile provides helpers for doing atomic file IO from Unity.
UniqueFileProducer implements a file base producer for strings.

## Wooga.Foundation.Json

Provides a common implementation for serializing/deserializing data to/from JSON. Currently this i backed by Newtonsoft.Json.

`Wooga.Foundation.Json.JSON` offers the following convenience methods:

```c#
public Serialize(object o, bool indent = false, int indentationAmount = 1, char indentationChar = ' ')

public static T Deserialize<T>(string input)

public static JSONNode Deserialize(string input)
```

untyped deserialization returns JSONNode/JSONObject/JSONArray for easy traversal

```c#
public interface JSONObject : JSONContainer, IDictionary<string, JSONNode>
{
    new JSONNode this[string propertyName] { get; set; }
}

public interface JSONArray : JSONContainer, IList<JSONNode>
{
    new JSONNode this[int index] { get; set; }
}

public abstract class JSONNode
{        
    public abstract JSONArray AsCollection(JSONArray defVal = null);

    public abstract JSONArray GetCollection(string key,JSONArray defVal = null);

    public abstract JSONNode GetNode(string key, JSONNode defVal = null);

    public abstract bool IsDictionary();

    public abstract bool IsCollection();

    public abstract bool HasKey(string key);

    public abstract JSONObject AsDictionary(JSONObject defVal = null);

    public abstract JSONObject GetDictionary(string key = null, JSONObject defVal = null);

    public abstract bool IsString();

    public abstract bool IsString(string key);

    public abstract String AsString();

    public abstract String GetString(string key, string defVal = null);

    public abstract bool IsNull();

    public abstract bool IsBoolean();

    public abstract bool AsBoolean();

    public abstract bool GetBoolean(string key, bool defVal = false);

    public abstract bool IsInt();

    public abstract int AsInt();

    public abstract int GetInt(string key, int defVal = 0);

    public abstract bool IsLong();

    public abstract long AsLong();

    public abstract long GetLong(string key, long defVal = 0);

    public abstract bool IsDouble();

    public abstract double AsDouble();

    public abstract double GetDouble(string key, double defVal = 0.0);

    public abstract bool IsFloat();

    public abstract float AsFloat();

    public abstract float GetFloat(string key, float defVal = 0.0f);

    public JSONNode this[string index]  

    public static explicit operator bool(JSONNode data)

    public static explicit operator string(JSONNode data)

    public static explicit operator double(JSONNode data)

    public static explicit operator float(JSONNode data)

    public static explicit operator long(JSONNode data)

    public static explicit operator int(JSONNode data)

```

## Wooga.Foundation.Sqlite

Offers access to sqlite databases on android and ios.
For documentation see:

codecoding/SQLite4Unity3d(https://github.com/codecoding/SQLite4Unity3d)

and

praeclarum/sqlite-net(https://github.com/praeclarum/sqlite-net)

## Wooga.Foundation.Tests.Unity3D

test tools for portable testing on unity devices and mono/.net installations

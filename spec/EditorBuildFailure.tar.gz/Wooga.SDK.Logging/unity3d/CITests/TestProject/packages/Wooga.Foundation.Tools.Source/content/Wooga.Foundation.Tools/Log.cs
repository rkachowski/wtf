﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Wooga.Foundation.Tools.LogReceivers;

#if UNITY_EDITOR
using UnityEditor;
#endif 

namespace Wooga.Foundation.Tools
{
    public static class Log
    {
        public static event LogHandler OnLog;

#if UNITY_EDITOR     
        public static bool UseColor = EditorPrefs.GetBool("_wdk_logging_colors", true);
        public static SeverityId MinSeverity = (SeverityId)EditorPrefs.GetInt("_wdk_logging_log_level", (int)SeverityId.Warning);
#else
        public static bool UseColor = false;
        public static SeverityId MinSeverity = SeverityId.Warning;
#endif

        static Log()
        {
            OnLog += UnityLogReceiver.Log;

            if (MinSeverity == SeverityId.NotSet)
            {
#if UNITY_EDITOR
                EditorPrefs.SetInt("_wdk_logging_log_level", (int)SeverityId.Warning);
#endif
                MinSeverity = SeverityId.Warning;
            }
        }

#region Public API
        public static void Error(string message)
        {
            HandleLog(message, SeverityId.Error);
        }

        public static void Warning(string message)
        {
            HandleLog(message, SeverityId.Warning);
        }

        public static void Info(string message)
        {
            HandleLog(message, SeverityId.Info);
        }

        public static void Debug(string message)
        {
            HandleLog(message, SeverityId.Debug);
        }
#endregion

        static void HandleLog(string message, SeverityId severity)
        {
            var logMessage = AssembleMessage(message, severity);
            OnLog(logMessage, severity);
        }

        private static string AssembleMessage(string message, SeverityId severity)
        {
            var stackFrame = new StackFrame(3, true);
            var builder = new StringBuilder();
            var fileName = Path.GetFileName(stackFrame.GetFileName());

#if UNITY_EDITOR
            if(UseColor)
                ColorLog(builder,stackFrame,fileName);
            else
                StandardLog(builder,stackFrame,fileName);
#else
            StandardLog(builder, stackFrame, fileName);
#endif
            builder.Append(" " + severity.ToString().ToUpper() + " ");
            builder.Append(message);

            return builder.ToString();
        }

        private static void ColorLog(StringBuilder builder, StackFrame stackFrame, string fileName)
        {
            builder.Append("<color=orange>[" + SDKFromFrame(stackFrame) + "]</color>");
            builder.Append(" <color=white>");
            builder.Append(fileName + ":" + stackFrame.GetFileLineNumber());
            builder.Append("</color> ");
        }

        private static void StandardLog(StringBuilder builder, StackFrame stackFrame, string fileName)
        {
            builder.Append("[" + SDKFromFrame(stackFrame) + "]");
            builder.Append(" ");
            builder.Append(fileName + ":" + stackFrame.GetFileLineNumber());
            builder.Append(" ");
        }

        private static string SDKFromFrame(StackFrame stackFrame)
        {
            var klass = stackFrame.GetMethod().ReflectedType;
            var namespace_ = klass.Namespace;
            var components = namespace_.Split('.').Distinct().ToList();

            components.Remove("Wooga");
            components.Remove("Services");
            components.Remove("Unity3D");

            return String.Join(".", components.ToArray());
        }

    }
    public enum SeverityId
    {
        NotSet = 0,
        /// <summary>
        /// Log everything
        /// </summary>
        Debug = 1,
        /// <summary>
        /// Log informational messages + warnings + errors
        /// </summary>
        Info,
        /// <summary>
        /// Log warning messages + errors
        /// </summary>
        Warning,
        /// <summary>
        ///  Log only errors
        /// </summary>
        Error,
        /// <summary>
        ///  Log nothing
        /// </summary>
        Silent
    }

    public delegate void LogHandler(string message, SeverityId severity);
 }

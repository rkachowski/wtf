﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Wooga.Foundation.Tools;

public class LogMenu
{
    public static readonly string EditorDebugLevelKey = "_wdk_logging_log_level";
    public static readonly string EditorLoggingColorKey = "_wdk_logging_colors";

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Error", false, 1)]
    static void SetError()
    {
        EditorPrefs.SetInt(EditorDebugLevelKey, (int)SeverityId.Error);
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Warning", false, 2)]
    static void SetWarning()
    {
        EditorPrefs.SetInt(EditorDebugLevelKey, (int)SeverityId.Warning);
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Info", false, 3)]
    static void SetInfo()
    {
        EditorPrefs.SetInt(EditorDebugLevelKey, (int)SeverityId.Info);
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Debug", false, 4)]
    static void SetDebug()
    {
        EditorPrefs.SetInt(EditorDebugLevelKey, (int)SeverityId.Debug);
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Silent", false, 51)]
    static void SetSilent()
    {
        EditorPrefs.SetInt(EditorDebugLevelKey, (int)SeverityId.Silent);
    }

    [MenuItem("Wooga/WDK/Logging/Enable Colored Log", false, 101)]
    static void EnableColorLog()
    {
        EditorPrefs.SetBool(EditorLoggingColorKey, true);
    }

    [MenuItem("Wooga/WDK/Logging/Disable Colored Log",false, 102)]
    static void DisableColorLog()
    {
        EditorPrefs.SetBool(EditorLoggingColorKey, false);
    }

#region Menu Validation Methods
    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Error", true)]
    static bool ValidateError()
    {
        return EditorPrefs.GetInt(EditorDebugLevelKey) != (int)SeverityId.Error;
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Silent", true)]
    static bool ValidateSilent()
    {
        return EditorPrefs.GetInt(EditorDebugLevelKey) != (int)SeverityId.Silent;
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Warning", true)]
    static bool ValidateWarning()
    {
        return EditorPrefs.GetInt(EditorDebugLevelKey) != (int)SeverityId.Warning;
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Info", true)]
    static bool ValidateInfo()
    {
        return EditorPrefs.GetInt(EditorDebugLevelKey) != (int)SeverityId.Info;
    }

    [MenuItem("Wooga/WDK/Logging/Set Logging Level/Debug", true)]
    static bool ValidateDebug()
    {
        return EditorPrefs.GetInt(EditorDebugLevelKey) != (int)SeverityId.Debug;
    }

    [MenuItem("Wooga/WDK/Logging/Enable Colored Log", true)]
    static bool ValidateEnableColorLog()
    {
        return EditorPrefs.GetBool(EditorLoggingColorKey) == false;
    }

    [MenuItem("Wooga/WDK/Logging/Disable Colored Log",true)]
    static bool ValidateDisableColorLog()
    {
        return EditorPrefs.GetBool(EditorLoggingColorKey) == true;
    }
#endregion
}


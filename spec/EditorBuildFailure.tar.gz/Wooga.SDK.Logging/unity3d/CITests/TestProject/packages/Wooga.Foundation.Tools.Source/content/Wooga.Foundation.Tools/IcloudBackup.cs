﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Wooga.ThreadSafe.Async;
using Wooga.Lambda.Data;
using UnityEngine;

namespace Wooga.Foundation.Tools
{
    public static class IcloudBackup
    {
        public static void Exclude(string fullPath)
        {
#if UNITY_IPHONE
                    AsyncExtensions.StartOnMainthread(() =>
					{	
#if UNITY_4_6 || UNITY_4_7
                       UnityEngine.iPhone.SetNoBackupFlag(fullPath);    
#else
                                
                        UnityEngine.iOS.Device.SetNoBackupFlag(fullPath);
#endif
                        return Unit.Default;
					});
#endif
        }
    }
}

﻿using NUnit.Framework.Api;
using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using NUnitLite.Runner;

namespace EAUnit.UnitTesting.TestWriter
{
    /// <summary>
    /// An xml output writer to create jenkins compatible junit xml with mobile platform package names 
    /// jenkins junit plugin does not correctly support junit, and this writer is a workaround
    /// </summary>
    class JenkinsJUnitXMLOutputWriter : OutputWriter
    {
        private DateTime runStartTime;
        private XmlWriter xmlWriter;

        //mapping NUnit.Framework.Api.TestStatus to the appropriate junit/jenkins format
        private static Dictionary<string, string> resultStates = new Dictionary<string, string>()
        {
            {"Failed", "failure"},
            {"Failed:Error","error"},
            {"Failed:Cancelled","failure"},
            {"Inconclusive","failure"},
            {"Skipped","skipped"},
            {"Skipped:Ignored","skipped"},
            {"Skipped:Invalid","skipped"}
        };

#if UNITY_IOS
        private static string PACKAGE = "iOS";
#elif UNITY_ANDROID
        private static string PACKAGE = "Android";
#else
        private static string PACKAGE = "Unknown Platform";
#endif

        public JenkinsJUnitXMLOutputWriter(DateTime runStartTime)
        {
            this.runStartTime = runStartTime;
        }

        public override void WriteResultFile(ITestResult result, TextWriter writer)
        {
            var settings = new XmlWriterSettings();
            settings.Indent = true;

            xmlWriter = XmlTextWriter.Create(writer,settings);
            
            try
            {
                WriteXmlOutput(result);
            }
            finally
            {
                writer.Close();
            }
        }

        private void WriteXmlOutput(ITestResult result)
        {
            xmlWriter.WriteStartDocument(false);

            xmlWriter.WriteStartElement("testsuites");

            foreach (var testsuite in result.Children)
            {
                WriteTestSuite(testsuite);
            }
            
            xmlWriter.WriteEndElement();//testsuites
            xmlWriter.WriteEndDocument();
            xmlWriter.Flush();
            xmlWriter.Close();
        }

        private void WriteTestSuite(ITestResult testsuite)
        {
            var summary = new ResultSummary(testsuite);
            xmlWriter.WriteStartElement("testsuite");

            xmlWriter.WriteAttributeString("name", testsuite.Name);
            xmlWriter.WriteAttributeString("tests", testsuite.Children.Count.ToString());
            xmlWriter.WriteAttributeString("time", testsuite.Duration.TotalSeconds.ToString());
            xmlWriter.WriteAttributeString("failures", testsuite.FailCount.ToString());
            xmlWriter.WriteAttributeString("errors", summary.ErrorCount.ToString());
            xmlWriter.WriteAttributeString("skipped", summary.IgnoreCount.ToString());

            foreach (var childtest in testsuite.Children)
            {
                if (childtest.Test is TestSuite)
                {
                    WriteTestSuite(childtest);
                }
                else
                {
                    WriteTestCase(childtest);
                }
            }

            xmlWriter.WriteEndElement();//testsuite
        }

        private void WriteTestCase(ITestResult testcase)
        {
            xmlWriter.WriteStartElement("testcase");
            var classname = PACKAGE + "." + "$DEVICEID$";
            xmlWriter.WriteAttributeString("classname", classname);
            xmlWriter.WriteAttributeString("name", testcase.Name);
            xmlWriter.WriteAttributeString("time", testcase.Duration.TotalSeconds.ToString());

            TestStatus status = testcase.ResultState.Status;

            if (status != TestStatus.Passed)
            {
                var elementName = resultStates[testcase.ResultState.ToString()];
                xmlWriter.WriteStartElement(elementName);

                switch (elementName)
                {
                    case "error":
                    case "failure":
                        xmlWriter.WriteAttributeString("message",testcase.Message + "\n deviceid = $DEVICEID$");
                        xmlWriter.WriteString(testcase.StackTrace);
                        break;
                    case "skipped":
                        xmlWriter.WriteAttributeString("message", testcase.Message);
                        break;
                    default:
                        throw new Exception("Unrecognised element name - "+elementName);
                }

                xmlWriter.WriteEndElement();//reason element
            }
            
            xmlWriter.WriteEndElement();//testcase
        }
    }
}

using NUnit.Framework.Api;
using NUnit.Framework.Internal;
using NUnitLite.Runner;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Reflection;
using System.Text;
using UnityEngine;
using Wooga.Services.ErrorAnalytics;
using EAUnit.UnitTesting.TestWriter;
using Wooga.DeviceInfo;

namespace NUnitLiteForUnity
{
    public class NUnitLiteForUnityTestListener : ITestListener
    {
        public void TestStarted(ITest test)
        {
            Debug.Log("TestStarted" + test.FullName + " : " + test.TestCaseCount);
        }

        public void TestFinished(ITestResult result)
        {
            Debug.Log("TestFinished " + result.ResultState + " " + result.FullName + " : " + result.Message);
        }

        public void TestOutput(TestOutput testOutput)
        {
        }
    }

    public static class NUnitLiteForUnityTestRunner
    {
#if UNITY_IOS && !UNITY_EDITOR
        private static string RESULT_FILE_LOCATION = Path.Combine(Application.persistentDataPath,"UnitTestResults.xml"); // Documents/UnitTestResults.xml on ios
#elif UNITY_ANDROID && !UNITY_EDITOR
        private static string RESULT_FILE_LOCATION = "/sdcard/UnitTestResults.xml";
#else
        private static string RESULT_FILE_LOCATION = "/var/tmp/UnitTestResults.xml";
#endif

        private static string TEST_START_TAG = "[TestRunStart]";
        private static string TEST_END_TAG = "[TestRunEnd]";

#region Public Methods


        public static string RunTests(string errorAnalyticsEndpoint, string assemblyName = "Assembly-CSharp")
        {
            DateTime startTime = DateTime.Now;
            Debug.Log(TEST_START_TAG);

            if (!ErrorAnalytics.isInitialized)
            {
                ErrorAnalytics.Init(errorAnalyticsEndpoint);
            }

            ITestAssemblyRunner testRunner = new NUnitLiteTestAssemblyRunner(new NUnitLiteTestAssemblyBuilder());

            Assembly testAssembly;

            try
            {
                testAssembly = Assembly.Load(assemblyName);
            }
            catch (Exception e)
            {
                var errorMessage = string.Format("Error encountered when loading assembly {0} - {0}", assemblyName,
                    e.ToString());
                Debug.Log(errorMessage);
                Debug.Log(TEST_END_TAG);
                return errorMessage;
            }

            bool hasTestLoaded = testRunner.Load(assembly: testAssembly, settings: new Hashtable());
            if (!hasTestLoaded)
            {
                var errorMessage = (string.Format("No tests found in assembly {0}", testAssembly.GetName().Name));
                Debug.Log(errorMessage);
                Debug.Log(TEST_END_TAG);
                return errorMessage;
            }

            ITestResult rootTestResult = testRunner.Run(new NUnitLiteForUnityTestListener(), TestFilter.Empty);

            new JenkinsJUnitXMLOutputWriter(startTime).WriteResultFile(rootTestResult, RESULT_FILE_LOCATION);
            Debug.Log(TEST_END_TAG);

            ResultSummary summary = new ResultSummary(rootTestResult);
            Debug.Log(ToSummaryString(summary));
            SendToErrorAnalytics(rootTestResult);

            return ToSummaryString(summary);
        }

        private static void SendToErrorAnalytics(ITestResult rootTestResult)
        {
            List<ITestResult> testResultList = EnumerateTestResult(rootTestResult).Where(it => !it.HasChildren).ToList();

            Debug.Log("These are the error:");
            DebugLogErrorResults(testResultList);

            // Send to EA
            foreach (var result in testResultList)
            {
                if (!(result.Test is TestSuite)
                    && result.ResultState != ResultState.Success
                    && result.ResultState != ResultState.Ignored
                    && result.ResultState != ResultState.Skipped)
                {
                    Log.Error(result.Name, result.Message);

                    Bundle.Init();

                    var message = "{\"text\": \"("+ SystemInfo.deviceModel +") Test "+ result.Name + " ("+Bundle.identifier+"-"+Bundle.version+") failed with "+result.Message+"\"}";

                    byte[] requestBytes = new UTF8Encoding().GetBytes(message);

                    var request = HttpWebRequest.Create("https://hooks.slack.com/services/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");
                    request.Method = WebRequestMethods.Http.Post;
                    request.ContentType = "application/json";
                    request.ContentLength = requestBytes.LongLength;

                    var reqStream = request.GetRequestStream();
                    reqStream.Write(requestBytes, 0, requestBytes.Length);
                    reqStream.Close();
                }
            }
        }

#endregion Public Methods



#region Private Methods

        private static string ToSummaryString(ResultSummary resultSummary)
        {
            using (StringWriter stringWriter = new StringWriter())
            {
                stringWriter.Write("{0} Tests :", resultSummary.TestCount);
                stringWriter.Write(" {0} Pass", resultSummary.PassCount);

                if (resultSummary.FailureCount > 0)
                {
                    stringWriter.Write(", {0} Failure", resultSummary.FailureCount);
                }

                if (resultSummary.ErrorCount > 0)
                {
                    stringWriter.Write(", {0} Error", resultSummary.ErrorCount);
                }

                if (resultSummary.NotRunCount > 0)
                {
                    stringWriter.Write(", {0} NotRun", resultSummary.NotRunCount);
                }

                if (resultSummary.InconclusiveCount > 0)
                {
                    stringWriter.Write(", {0} Inconclusive", resultSummary.InconclusiveCount);
                }

                return stringWriter.GetStringBuilder().ToString();
            }
        }

        private static IEnumerable<ITestResult> EnumerateTestResult(ITestResult result)
        {
            if (result.HasChildren)
            {
                foreach (ITestResult child in result.Children)
                {
                    foreach (ITestResult c in EnumerateTestResult(child))
                    {
                        yield return c;
                    }
                }
            }
            yield return result;
        }

        private static void DebugLogErrorResults(IEnumerable<ITestResult> testResults)
        {
            foreach (ITestResult testResult in testResults)
            {
                if (testResult.ResultState == ResultState.Error || testResult.ResultState == ResultState.Failure)
                {
                    string foramt = "{0}\n{1} ({2})\n{3}\n{4}";
                    string log = string.Format(foramt, testResult.ResultState, testResult.Name, testResult.FullName, testResult.Message, testResult.StackTrace);
                    Debug.Log(log);
                }
            }
        }

#endregion Private Methods
    }
}

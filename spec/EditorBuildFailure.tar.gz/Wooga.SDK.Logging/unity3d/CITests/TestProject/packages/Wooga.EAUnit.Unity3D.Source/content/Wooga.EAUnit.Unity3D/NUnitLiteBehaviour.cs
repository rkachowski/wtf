using UnityEngine;
using System.Collections;
using System.Net;
using NUnitLiteForUnity;

public class NUnitLiteBehaviour : MonoBehaviour {

    private string _testMessage = "Not setup";
    private int frameCount = 0;
    private bool isRunning = false;

    void Update () {
        if (frameCount > 2)
        {
            if( !isRunning  ) {
                string eaEndpoint = "goxp4r4otf3pc7nt2zklriby"; // SDK CI Tests
                _testMessage = Application.bundleIdentifier +" test results : " + NUnitLiteForUnityTestRunner.RunTests(eaEndpoint);
                isRunning = true;
            }
        }
        else
        {
            _testMessage = "Running " + Application.bundleIdentifier + " tests";
        }

        frameCount++;
    }

    void OnGUI()
    {
        var style = GUI.skin.GetStyle("box");
        style.fontSize = 32;
        var rect = new Rect(5,5,Screen.width-5, Screen.height - 5);
        GUI.Box(rect, _testMessage);
    }
}

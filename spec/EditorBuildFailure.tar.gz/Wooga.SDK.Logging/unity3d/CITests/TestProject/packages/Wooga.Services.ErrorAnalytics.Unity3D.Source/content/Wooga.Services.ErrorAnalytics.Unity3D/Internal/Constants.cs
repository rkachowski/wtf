﻿namespace Wooga.Services.ErrorAnalytics
{
    internal static class Constants
    {
        public const string MetaPrefix = "__SDK_EA_";
        public const string MetaKeyOverflowError = MetaPrefix + "overflow_error";
        public const int MaxMetaDataSize = 1500;
        public const int MaxParseableExceptionLogSize = 200;
        public const string UserMetaDataObjectsKey = "SerializedObjects";
    }
}
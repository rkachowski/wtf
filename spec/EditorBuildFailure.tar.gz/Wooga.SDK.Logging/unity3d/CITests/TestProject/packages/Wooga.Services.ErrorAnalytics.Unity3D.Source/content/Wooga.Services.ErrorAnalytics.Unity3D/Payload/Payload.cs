﻿using System;
using System.Collections.Generic;
using Wooga.Foundation.Json;

namespace Wooga.Services.ErrorAnalytics
{
    internal static class Payload
    {
        public static readonly string NotifierVersion = "2.0.0";

        public static string SerializeErrorPayload(Information.Sbs sbsInfo,
            Event[] events)
        {
            var data = new Dictionary<string, object>
            {
                {"notifierVersion", NotifierVersion},
                {"sbsInfo", sbsInfo.ToDict()}
            };

            if (events != null)
            {
                var serializedEvents = new Dictionary<string, object>[events.Length];

                for (var i = 0; i < events.Length; i++)
                {
                    var e = events[i];
                    e.MetaData = NormalizeMetaData(e.MetaData);
                    serializedEvents[i] = e.ToDict();
                }

                data["events"] = serializedEvents;
            }

            return JSON.Serialize(data);
        }

        public static string SerializeStartPayload(Information.Sbs sbsInfo, Start payload)
        {
            var data = new Dictionary<string, object>
            {
                {"notifierVersion", NotifierVersion},
                {"sbsInfo", sbsInfo.ToDict()},
                {"createdAt", payload.CreatedAt},
                {"device", payload.DeviceInfo},
                {"app", payload.AppInfo.ToDict()},
                {"userId", payload.UserId}
            };

            return JSON.Serialize(data);
        }

        private static Dictionary<string, object> NormalizeMetaData(Dictionary<string, object> metaData)
        {
            var normalizedMetaData = new Dictionary<string, object>();
            var truncatedKeys = new List<string>();
            foreach (var item in metaData)
            {
                try
                {
                    if (JSON.Serialize(new[] {item.Value}).Length < Constants.MaxMetaDataSize)
                    {
                        normalizedMetaData[item.Key] = item.Value;
                    }
                    else
                    {
                        var str = item.Value as string;
                        if (str != null)
                        {
                            var truncatedValue = str.Substring(0, Constants.MaxMetaDataSize);
                            normalizedMetaData[item.Key] = truncatedValue;
                        }

                        truncatedKeys.Add(item.Key);
                    }
                }
                catch (Exception ex)
                {
                    normalizedMetaData[item.Key] = "ErrorAnalytics: Failed to serialize object: " + ex;
                }
            }

            if (truncatedKeys.Count > 0)
            {
                var keys = "";
                foreach (var key in truncatedKeys)
                {
                    keys += key + " ";
                }

                normalizedMetaData[Constants.MetaKeyOverflowError] =
                    "The following keys were truncated/removed because their values were too large: " + keys;
            }

            return normalizedMetaData;
        }

        public struct Start
        {
            public readonly Information.App AppInfo;
            public readonly int CreatedAt;
            public readonly Dictionary<string, object> DeviceInfo;
            public readonly string UserId;

            public Start(
                int createdAt,
                Dictionary<string, object> deviceInfo,
                Information.App appInfo,
                string userId
                )
            {
                CreatedAt = createdAt;
                DeviceInfo = deviceInfo;
                AppInfo = appInfo;
                UserId = userId;
            }
        }

        public struct Event
        {
            public readonly Information.App AppInfo;
            public readonly string[] Breadcrumbs;
            public readonly int CreatedAt;
            //			public readonly String AppState;
            public readonly Dictionary<string, object> DeviceInfo;
            public readonly string ErrorType;
            public readonly string Message;
            public readonly string RawStacktrace;
            public readonly ErrorAnalytics.LogSeverity Severity;
            public readonly ParsingUtility.StackTraceElement[] StackTrace;
            public readonly string UserId;
            public Dictionary<string, object> MetaData;

            public Event(int createdAt,
                ErrorAnalytics.LogSeverity severity,
                string userId,
                string errorType,
                string message,
                Information.App appInfo,
                string rawStackTrace,
                ParsingUtility.StackTraceElement[] stackTrace,
                string[] breadcrumbs,
                Dictionary<string, object> deviceInfo,
                Dictionary<string, object> metaData
                )
            {
                CreatedAt = createdAt;
                Severity = severity;
                UserId = userId;
                ErrorType = errorType;
                Message = message;
                AppInfo = appInfo;
                RawStacktrace = rawStackTrace;
                StackTrace = stackTrace;
                Breadcrumbs = breadcrumbs;
                DeviceInfo = deviceInfo;
                MetaData = metaData;
            }

            public Dictionary<string, object> ToDict()
            {
                var dict = new Dictionary<string, object>
                {
                    {"createdAt", CreatedAt},
                    {"severity", SeverityToString(Severity)},
                    {"userId", UserId},
                    {"errorType", ErrorType},
                    {"message", Message},
                    {"app", AppInfo.ToDict()},
                    {"stacktraceRaw", RawStacktrace}
                };

                if (StackTrace != null)
                {
                    dict["stacktrace"] = StackTrace;
                }

                if (Breadcrumbs != null)
                {
                    dict["breadcrumbs"] = Breadcrumbs;
                }

                if (DeviceInfo != null)
                {
                    dict["device"] = DeviceInfo;
                }

                if (MetaData != null)
                {
                    dict["metaData"] = MetaData;
                }

                return dict;
            }

            private string SeverityToString(ErrorAnalytics.LogSeverity sev)
            {
                switch (sev)
                {
                    case ErrorAnalytics.LogSeverity.Warning:
                        return "warning";

                    case ErrorAnalytics.LogSeverity.Error:
                        return "error";

                    case ErrorAnalytics.LogSeverity.Fatal:
                        return "fatal";
                }
                return "unknown severity";
            }
        }
    }
}
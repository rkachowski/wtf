﻿using System;
using UnityEngine;
using System.Collections.Generic;
using Wooga.Lambda.Control.Concurrent;

namespace Wooga.Services.ErrorAnalytics
{
    internal static class Handler
    {
        public static Action<ParsedException> exceptionCallback = ex => { };

        public static void Init()
        {
#if NOT_UNITY
            return;
#elif UNITY_5_0 || UNITY_5_1 || UNITY_5_2 || UNITY_5_3 || UNITY_5_4 || UNITY_5_5
            Application.logMessageReceivedThreaded += HandleLog;
#else
            Application.RegisterLogCallback(HandleLog);
#endif

            AppDomain.CurrentDomain.UnhandledException += HandleUnhandledException;
            Async.AsyncComputationExceptionEvent += HandleException;
        }

        /// <summary>
        /// This handles exception events dispatched through Async.DispatchException mechanism
        /// </summary>
        /// <param name="exc">Exception</param>
        static void HandleException(Exception exc)
        {
			var exceptionUUID = System.Guid.NewGuid().ToString("N");
			var metaData = new Dictionary<string,object>();
			metaData["exUUID"] = exceptionUUID;

            Log.Fatal(exc, null, metaData);
            ParsedException parsedExc = new ParsedException();

			parsedExc.uuid = exceptionUUID;
            parsedExc.errorClass = exc.GetType().Name;
            parsedExc.errorMessage = exc.Message;
            parsedExc.stackTrace = exc.StackTrace;

            exceptionCallback(parsedExc);
        }

        /// <summary>
        ///     This catches unhandled exceptions when script optimization is set to fast, but no exceptions.
        ///     For this to work on ios we have to disable the unity crash reporting. This can be done in the xcode
        ///     project modifying the file Classes->CrashReporter.mm.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        private static void HandleUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var exc = e.ExceptionObject as Exception;

			var exceptionUUID = System.Guid.NewGuid().ToString("N");
			var metaData = new Dictionary<string,object>();
			metaData["exUUID"] = exceptionUUID;

            Log.Fatal(exc, null, metaData);
            var parsedExc = new ParsedException();

			parsedExc.uuid = exceptionUUID;
            parsedExc.errorClass = exc.GetType().Name;
            parsedExc.errorMessage = exc.Message;
            parsedExc.stackTrace = exc.StackTrace;

            exceptionCallback(parsedExc);
        }

        /// <summary>
        ///     This is currently only used to catch Exceptions. If you want to notify about
        ///     less severe errors use the public Notify(Exception,object) method.
        /// </summary>
        /// <param name="logString">Log string.</param>
        /// <param name="stackTrace">Stack trace.</param>
        /// <param name="type">Type.</param>
        private static void HandleLog(string logString, string stackTrace, LogType type)
        {
            if (type == LogType.Exception || type == LogType.Error)
            {
                var severity = type == LogType.Exception
                    ? ErrorAnalytics.LogSeverity.Fatal
                    : ErrorAnalytics.LogSeverity.Error;
                var ex = ParsingUtility.ParseExceptionLog(logString, severity);

                ex.stackTrace = stackTrace;
                var elements = ParsingUtility.ParseStackTraceElements(stackTrace, ParsingUtility.ParseType.LogStackTrace);

				var exceptionUUID = System.Guid.NewGuid().ToString("N");
				var metaData = new Dictionary<string,object>();
				metaData["exUUID"] = exceptionUUID;
				ex.uuid = exceptionUUID;

                ErrorAnalytics.StoreAndForwardError(ex.errorClass, ex.errorMessage, stackTrace, elements, severity, metaData);

                exceptionCallback(ex);
            }
        }
    }
}

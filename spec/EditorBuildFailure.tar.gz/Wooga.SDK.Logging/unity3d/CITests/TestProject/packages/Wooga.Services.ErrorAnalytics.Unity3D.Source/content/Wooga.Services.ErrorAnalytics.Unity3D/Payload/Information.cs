﻿using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using Wooga.DeviceInfo;

namespace Wooga.Services.ErrorAnalytics
{
    public static class Information
    {
        internal static Sbs.Platform GetSbsPlatform()
        {
            var system = Sbs.Platform.Unknown;

#if !NOT_UNITY
            //TODO add unity editor case ?
            if (Application.platform == RuntimePlatform.Android)
            {
                system = Sbs.Platform.Android;
            }
            else if (Application.platform == RuntimePlatform.IPhonePlayer)
            {
                system = Sbs.Platform.IOS;
            }
#endif
            return system;
        }

        internal static Device GetDevice()
        {
            //TODO get realer data
#if NOT_UNITY
            return new Device(
                DeviceId.uniqueIdentifier,
                ".net/mono",
                5,
                5,
                "osversion",
                0, //TODO add API level
                "Unity Incorporated",
                "Standalone",
                false, //TODO is jailbroken?
                "en_US",
                "100x100",
                "osname",
                10,
                false);
#endif
            var resolution = Screen.currentResolution.width + "x" + Screen.currentResolution.height;

            const float MIN_RETINA_DPI = 218;

            return new Device(
                DeviceId.uniqueIdentifier,
#if UNITY_ANDROID && !UNITY_EDITOR
                DeviceId.AndroidModel(),
#else
                SystemInfo.deviceModel,
#endif
                (uint) SystemInfo.systemMemorySize,
                (uint) SystemInfo.systemMemorySize,
                GetOSVersion(),
#if UNITY_ANDROID && !UNITY_EDITOR
                (uint) DeviceId.AndroidApiLevel(),
                DeviceId.AndroidManufacturer(),
                DeviceId.AndroidDeviceCode(),
#elif UNITY_IOS && !UNITY_EDITOR
                0, //TODO add API level
                "",
                "",
#else
                0,
                "",
                "",
#endif
                Wooga.DeviceInfo.Unity3D.Platform.isJailbroken(),
                Application.systemLanguage.ToString(),
                resolution,
                GetOSName(),
                (uint) Screen.dpi,
                (Screen.dpi > MIN_RETINA_DPI)
                );
        }

        internal static string GetOSVersion()
        {
            var os = SystemInfo.operatingSystem;
            var versionRegex = new Regex(@"(?<version>\d(\.\d)+)");
            var versionMatches = versionRegex.Match(os);
            return versionMatches.Groups["version"].Value;
        }

        internal static string GetOSName()
        {
            var os = SystemInfo.operatingSystem;
            var nameRegex = new Regex(@"^(?<name>\w+)");
            var nameMatches = nameRegex.Match(os);
            return nameMatches.Groups["name"].Value;
        }

        internal static string BackendCompatibleString(this Sbs.Platform system)
        {
            //Note: These are the strings that are expected by the backend
            switch (system)
            {
                case Sbs.Platform.Android:
                    return "android";

                case Sbs.Platform.IOS:
                    return "ios";

                default:
                    return "unknownsystem";
            }
        }

        internal struct Device
        {
            public readonly uint ApiLevel;
            public readonly string Id;
            public readonly bool IsRetina;
            public readonly bool Jailbroken;
            public readonly string Locale;
            public readonly string Model;
            public readonly string Manufacturer;
            public readonly string DeviceCode;
            public readonly string OsName;
            public readonly string OsVersion;
            public readonly uint PhysicalRamSize;
            public readonly uint ScreenDensity;
            public readonly string ScreenResolution;
            public readonly uint TotalMemory;

            public Device(
                string id,
                string model,
                uint physicalRamSize,
                uint totalMemory,
                string osVersion,
                uint apiLevel,
                string manufacturer,
                string deviceCode, 
                bool jailbroken,
                string locale,
                string screenResolution,
                string osName,
                uint screenDensity,
                bool isRetina)
            {
                Manufacturer = manufacturer;
                DeviceCode = deviceCode;
                Id = id;
                Model = model;
                PhysicalRamSize = physicalRamSize;
                TotalMemory = totalMemory;
                OsVersion = osVersion;
                ApiLevel = apiLevel;
                Jailbroken = jailbroken;
                Locale = locale;
                ScreenResolution = screenResolution;
                OsName = osName;
                ScreenDensity = screenDensity;
                IsRetina = isRetina;
            }

            public Dictionary<string, object> ToDict()
            {
                return new Dictionary<string, object>
                {
                    {"manufacturer", Manufacturer},
                    {"deviceCode", DeviceCode},
                    {"model", Model},
                    {"physicalRamSize", PhysicalRamSize},
                    {"totalMemory", TotalMemory},
                    {"osVersion", OsVersion},
                    {"apiLevel", ApiLevel},
                    {"jailbroken", Jailbroken},
                    {"locale", Locale},
                    {"screenResolution", ScreenResolution},
                    {"osName", OsName},
                    {"screenDensity", ScreenDensity},
                    {"isRetina", IsRetina}
                };
            }
        }

        /// <summary>
        /// Information about the application using ErrorAnalytics
        /// </summary>
        public struct App
        {
            public string BundleIdentifier;
            public string TechnicalVersion;
            public string Version;

            /// <summary>
            ///     Initializes a new instance of the <see cref="Wooga.Services.ErrorAnalytics.Information+App" /> struct.
            /// </summary>
            /// <param name="bundleIdentifier">Bundle identifier.</param>
            /// <param name="technicalVersion">Technical version.</param>
            /// <param name="version">Version. Mandatory as per ErrorAnalytics backend!</param>
            public App(
                string version,
                string technicalVersion,
                string bundleIdentifier
                )
            {
                BundleIdentifier = bundleIdentifier;
                TechnicalVersion = technicalVersion;
                Version = version;
            }

            public Dictionary<string, object> ToDict()
            {
                return new Dictionary<string, object>
                {
                    {"version", Version},
                    {"technicalVersion", TechnicalVersion},
                    {"bundleId", BundleIdentifier}
                };
            }
        }

        /// <summary>
        /// SBS data
        /// </summary>
        public struct Sbs
        {
            public enum Platform
            {
                Unknown,
                Android,
                IOS
            }

            public string DeviceId;
            public string GameId;
            public Platform System;
            public string UserId;

            public Sbs(string deviceId,
                string gameId,
                Platform system,
                string userId)
            {
                DeviceId = deviceId;
                GameId = gameId;
                System = system;
                UserId = userId;
            }

            public Dictionary<string, object> ToDict()
            {
                return new Dictionary<string, object>
                {
                    {"gameId", GameId},
                    {"system", System.BackendCompatibleString()},
                    {"userId", UserId},
                    {"deviceId", DeviceId}
                };
            }
        }
    }
}
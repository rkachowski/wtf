﻿using System;
using System.Collections.Generic;
using Wooga.ThreadSafe;

namespace Wooga.Services.ErrorAnalytics
{
    public static class Log
    {
        public delegate void LogHandler(string message);

        private const string _emptyMessage = "";

        public static LogHandler logHandler = Console.WriteLine;

        public static bool LogToErrorAnalytics = false;

        private static void NotifyError(ErrorAnalytics.LogSeverity severity, Exception exception, string message,
            Dictionary<string, object> metaData)
        {
            string rawStackTrace;
            List<ParsingUtility.StackTraceElement> parsedStackTrace;

            if (string.IsNullOrEmpty(exception.StackTrace))
            {
                rawStackTrace = Environment.StackTrace;
                parsedStackTrace = ParsingUtility.ParseStackTraceElements(rawStackTrace,
                    ParsingUtility.ParseType.EnvironmentStackTrace);
            }
            else
            {
                rawStackTrace = exception.StackTrace;
                parsedStackTrace = ParsingUtility.ParseStackTraceElements(rawStackTrace,
                    ParsingUtility.ParseType.UnhandledExceptionStackTrace);
            }

            message = message ?? _emptyMessage;
            ErrorAnalytics.StoreAndForwardError(exception.GetType().ToString(), message, rawStackTrace, parsedStackTrace,
                severity, metaData);
        }

        private static void NotifyError(ErrorAnalytics.LogSeverity severity, string errorType, string message,
            Dictionary<string, object> metaData)
        {
            var rawStackTrace = Environment.StackTrace;
            var stackTrace = ParsingUtility.ParseStackTraceElements(rawStackTrace,
                ParsingUtility.ParseType.EnvironmentStackTrace);
            message = message ?? _emptyMessage;
            ErrorAnalytics.StoreAndForwardError(errorType, message, rawStackTrace, stackTrace, severity, metaData);
        }

        #region Public API

        public static void InfoBreadcrumb(string message)
        {
            var time = Time.Now() + ": ";

            ErrorAnalytics.AddBreadcrumb(time + message);

#if (UNITY_EDITOR || DEVELOPMENT_BUILD)
            logHandler("[INFO] " + time + message);
#endif
        }

        public static void Debug(string message)
        {
            var time = Time.Now() + ": ";

#if (UNITY_EDITOR || DEVELOPMENT_BUILD)
            logHandler("[DEBUG] " + time + message);
#endif
        }

        static void Notify(ErrorAnalytics.LogSeverity severity, Exception ex, string message, Dictionary<string, object> metaData, Action<string> logHandler)
        {
            if (LogToErrorAnalytics)
            {
                NotifyError(severity, ex, message, metaData);
                return;
            }
#if !NOT_UNITY
            logHandler(ex.Message+(ex.StackTrace != null ? "\n" + ex.StackTrace : ""));
#endif
        }

        static void Notify(ErrorAnalytics.LogSeverity severity, string errorType, string message, Dictionary<string, object> metaData, Action<string> logHandler)
        {
            if (LogToErrorAnalytics)
            {
                NotifyError(severity, errorType, message, metaData);
                return;
            }
#if !NOT_UNITY
            logHandler(message);
#endif
        }

        public static void Warning(Exception exception, string message = null,
            Dictionary<string, object> metaData = null)
        {
            Notify(ErrorAnalytics.LogSeverity.Warning, exception, message, metaData, UnityEngine.Debug.LogWarning);
        }

        public static void Error(Exception exception, string message = null, Dictionary<string, object> metaData = null)
        {
            Notify(ErrorAnalytics.LogSeverity.Error, exception, message, metaData, UnityEngine.Debug.LogError);
        }

        public static void Fatal(Exception exception, string message = null, Dictionary<string, object> metaData = null)
        {
            Notify(ErrorAnalytics.LogSeverity.Fatal, exception, message, metaData, UnityEngine.Debug.LogError);
        }

        public static void Warning(string errorType, string message = null, Dictionary<string, object> metaData = null)
        {
            Notify(ErrorAnalytics.LogSeverity.Warning, errorType, message, metaData, UnityEngine.Debug.LogWarning);
        }

        public static void Error(string errorType, string message = null, Dictionary<string, object> metaData = null)
        {
            Notify(ErrorAnalytics.LogSeverity.Error, errorType, message, metaData, UnityEngine.Debug.LogError);
        }

        public static void Fatal(string errorType, string message = null, Dictionary<string, object> metaData = null)
        {
            Notify(ErrorAnalytics.LogSeverity.Fatal, errorType, message, metaData, UnityEngine.Debug.LogError);
        }

        #endregion
    }
}
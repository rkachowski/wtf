﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using UnityEngine;
using Wooga.DeviceInfo;
using Wooga.Lambda.Control.Concurrent;
using Wooga.Lambda.Data;
using Wooga.Lambda.Network.Transport;
using Wooga.Lambda.Storage;
using Wooga.ThreadSafe;
using Wooga.ThreadSafe.Async;
using Time = Wooga.ThreadSafe.Time;

namespace Wooga.Services.ErrorAnalytics
{
    public static class ErrorAnalytics
    {
        private static bool _isInitalized = false;

        public static bool isInitialized
        {
            get { return _isInitalized; }
        }


        internal enum LogSeverity
        {
            Fatal = 1,
            Error = 2,
            Warning = 3
        }

        private static Breadcrumbs _breadrumbs;
        private static Reporter _reporter;
        private static Information.Sbs _sbsInfo;
        private static Information.App _appInfo;
        private static Information.Device _deviceInfo;
        private static Dictionary<string, object> _deviceInfoDict = null;
        private static string _customUserId = "";

        private const string DataPath = "ea_cache_unity";

        private static readonly Dictionary<string, object> _objectsToSerialize = new Dictionary<string, object>();
        private static readonly object _objectsToSerializeLock = new object();

        #region Public API

        internal static void Init(Reporter reporter, string sbsGameId)
        {
            _reporter = reporter;
            Init(sbsGameId);
        }

        /// <summary>
        ///     Initialize ErrorAnalytics.
        ///     Important: This method MUST be called from the main thread.
        /// </summary>
        /// <param name="sbsGameId">Sbs game identifier.</param>
        /// <param name="breadCrumbCapacity">Bread crumb capacity.</param>
        /// <param name="enableErrorHandlingInEditor">Errors are not handled in the editor by default. Set this to true to handle them anyway.</param>
        public static void Init(string sbsGameId, int breadCrumbCapacity = 50, bool enableErrorHandlingInEditor = false)
        {
            Init(
                sbsGameId,
                new Information.App(
                    Bundle.version,
                    Bundle.build,
                    Bundle.identifier
                    ),
#if NOT_UNITY
                Path.GetTempPath(),
#else
                Application.temporaryCachePath,
#endif
                breadCrumbCapacity,
                enableErrorHandlingInEditor
                );
        }

        /// <summary>
        ///     Initialize ErrorAnalytics.
        ///     Important: This method MUST be called from the main thread.
        /// </summary>
        /// <param name="sbsGameId">Sbs game identifier.</param>
        /// <param name="appInfo">App info.</param>
        /// <param name="breadCrumbCapacity">Bread crumb capacity.</param>
        /// <param name="enableErrorHandlingInEditor">Errors are not handled in the editor by default. Set this to true to handle them anyway.</param>
        public static void Init(string sbsGameId, Information.App appInfo, int breadCrumbCapacity = 50, bool enableErrorHandlingInEditor = false)
        {
            Init(sbsGameId, appInfo, Application.temporaryCachePath, breadCrumbCapacity, enableErrorHandlingInEditor);
        }

        internal static void Init(string sbsGameId,
            Information.App appInfo,
            string applicationTemporaryCachePath,
            int breadCrumbCapacity = 50,
            bool enableErrorHandlingInEditor = false)
        {
            if (isInitialized)
            {
                return;
            }

            if (string.IsNullOrEmpty(_customUserId))
            {
                _customUserId = DeviceId.uniqueIdentifier;
            }

            _breadrumbs = new Breadcrumbs(breadCrumbCapacity);
            _sbsInfo.GameId = sbsGameId;
            _sbsInfo.System = Information.GetSbsPlatform();
            _appInfo = appInfo;
            _deviceInfo = Information.GetDevice();
            _deviceInfoDict = _deviceInfo.ToDict();
#if !NOT_UNITY
            Unity3D.Init();
#endif
            ServicePointManager.ServerCertificateValidationCallback = (xsender, xcertificate, xchain, xerrors) => true;

            var storage = LocalFileSystem.Create();
            if (_reporter == null)
            {
                _reporter = new Reporter(storage,
                    WebRequestTransport.CreateHttpClient(),
                    Path.Combine(applicationTemporaryCachePath, DataPath));
                _reporter.GameId = sbsGameId;
            }

            _isInitalized = true; // this really has to be up here as UpdateSbsInfoNative relies on it

#if !NOT_UNITY
            SbsNativeErrorAnalytics.InitErrorAnalytics(sbsGameId, _customUserId, appInfo);
            SbsNativeErrorAnalytics.SetBreadcrumbBufferSize(breadCrumbCapacity);

            UpdateSbsInfoNative(_sbsInfo.DeviceId, _sbsInfo.UserId);

            // if we are in the editor, init only if enableErrorHandlingInEditor is set. Otherwise always enable it.
            if ( !(Application.platform == RuntimePlatform.OSXEditor || Application.platform == RuntimePlatform.WindowsEditor) || enableErrorHandlingInEditor )
            {
                Handler.Init();
                Log.LogToErrorAnalytics = true;
            }
#endif
            NotifyStart();
        }

        public static void NotifyStart()
        {
            if (!isInitialized)
            {
                return;
            }

            var time = Time.EpochTime();

            var startPayload = new Payload.Start(time, _deviceInfoDict, _appInfo, _customUserId);
            var serializedPayload = Payload.SerializeStartPayload(_sbsInfo, startPayload);

            _reporter.ReportStart(serializedPayload, _sbsInfo, _appInfo, _customUserId).RunSynchronously();
            _reporter.DeliverReportsInBackground();
        }


        /// <summary>
        ///     Updates the SBS info.
        ///     Limitation: The Java error handler has its own copy of this information which is *not* updated if this
        ///     method is called from a different thread than the main thread.
        /// </summary>
        /// <param name="deviceId">Device identifier</param>
        /// <param name="userId">User identifier</param>
        public static void UpdateSbsInfo(string deviceId, string userId)
        {
            _sbsInfo.DeviceId = deviceId;
            _sbsInfo.UserId = userId;

            UpdateSbsInfoNative(deviceId, userId);
        }

        private static void UpdateSbsInfoNative(string deviceId, string userId)
        {
            if (isInitialized)
            {
#if NOT_UNITY
                return;

#elif UNITY_ANDROID && !UNITY_EDITOR
    //On Android we can't call JNI methods from other threads, so we don't call this at all for now
                if(Unity3D.Threads.OnMainThread())
                {
                    SbsNativeErrorAnalytics.SetSBSDeviceId(deviceId);
                    SbsNativeErrorAnalytics.SetSBSUserId(userId);
                }else{
                    AsyncExtensions.StartOnMainthread(() =>
                    {
                        SbsNativeErrorAnalytics.SetSBSDeviceId(deviceId);
                        SbsNativeErrorAnalytics.SetSBSUserId(userId);
                        return Unit.Default;
                    });
                }
#else
                SbsNativeErrorAnalytics.SetSBSDeviceId(deviceId);
                SbsNativeErrorAnalytics.SetSBSUserId(userId);
#endif
            }
        }

        public static void UpdateCustomUserId(string customUserId)
        {
            _customUserId = customUserId;
        }

        /// <summary>
        ///     Adds a breadcrumb (a user-defined string to trace the code path of an error)
        ///     Limitation: Errors caught by the native Java crash handler will not contain breadcrumbs which were set from a
        ///     different than the main thread.
        /// </summary>
        /// <param name="breadcrumb">A breadcrumb</param>
        public static void AddBreadcrumb(string breadcrumb)
        {
            /* TODO (asc 2015-04-07) we have a limitation here that for Java and JNI code we can only add breadcrumbs from the main thread.
            * Not sure if that is fixable (we'd have to switch to the main thread to add the breadcrumb) */

#if UNITY_EDITOR // game teams want to be able to start individual scenes in the unity editor, which might bypass initialization
            if (!isInitialized) return;
#endif
            _breadrumbs.Append(breadcrumb);

#if NOT_UNITY
            return;

#elif UNITY_ANDROID && !UNITY_EDITOR
            if(Unity3D.Threads.OnMainThread())
            {
                SbsNativeErrorAnalytics.AddBreadcrumb(breadcrumb);
            }else{
                AsyncExtensions.StartOnMainthread(() =>
                {
                    SbsNativeErrorAnalytics.AddBreadcrumb(breadcrumb);
                    return Unit.Default;
                });
            }
#else
            SbsNativeErrorAnalytics.AddBreadcrumb(breadcrumb);
#endif
        }

        public static void SetExceptionCallback(Action<ParsedException> callback)
        {
            Handler.exceptionCallback = callback;
        }

        public static void RegisterObjectToSerialize(string key, object obj)
        {
            lock (_objectsToSerializeLock)
            {
                _objectsToSerialize[key] = obj;
            }
        }

        public static void UnregisterObjectToSerialize(string key)
        {
            lock (_objectsToSerializeLock)
            {
                if (_objectsToSerialize.ContainsKey(key))
                {
                    _objectsToSerialize.Remove(key);
                }
            }
        }

#endregion

        internal static void StoreAndForwardError(string errorType,
            string message,
            string rawStackTrace,
            List<ParsingUtility.StackTraceElement> stackTrace,
            LogSeverity severity,
            Dictionary<string, object> metaData)
        {
            if (!isInitialized)
            {
                return;
            }

            metaData = AddExternalObjectsToMetaData(metaData);

            var e = new Payload.Event(
                Time.EpochTime(),
                severity,
                _customUserId,
                errorType,
                message,
                _appInfo,
                rawStackTrace,
                stackTrace.ToArray(),
                _breadrumbs.ToArray(),
                _deviceInfoDict,
                metaData);

            var p = Payload.SerializeErrorPayload(_sbsInfo, new[] {e});
            _reporter.ReportError(p, _sbsInfo, _appInfo, _customUserId).RunSynchronously();
            _reporter.DeliverReportsInBackground();
        }

        private static Dictionary<string, object> AddExternalObjectsToMetaData(Dictionary<string, object> metaData)
        {
            Dictionary<string, object> newMetaData;
            newMetaData = metaData != null ? new Dictionary<string, object>(metaData) : new Dictionary<string, object>();

            if (_objectsToSerialize.Count <= 0) return newMetaData;
            
            lock (_objectsToSerializeLock)
            {
                try
                {
                    newMetaData[Constants.UserMetaDataObjectsKey] = _objectsToSerialize;
                }
                catch (Exception ex)
                {
                    newMetaData[Constants.UserMetaDataObjectsKey] =
                        "ErrorAnalytics: Failed to serialize user objects: " + ex;
                }
            }

            return newMetaData;
        }
    }
}
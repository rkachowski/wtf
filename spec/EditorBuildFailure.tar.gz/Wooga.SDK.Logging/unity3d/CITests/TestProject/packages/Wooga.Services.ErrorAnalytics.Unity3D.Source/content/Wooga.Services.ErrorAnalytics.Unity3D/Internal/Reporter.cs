﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Wooga.Foundation.Json;
using Wooga.Foundation.Sqlite;
using Wooga.Foundation.Tools;
using Wooga.Lambda.Control.Concurrent;
using Wooga.Lambda.Control.Monad;
using Wooga.Lambda.Data;
using Wooga.Lambda.Network;
using Wooga.Lambda.Storage;
using Wooga.ThreadSafe;

namespace Wooga.Services.ErrorAnalytics
{
    internal class Reporter
    {
        private static readonly Uri Host = new Uri("https://ea.sbs.wooga.com");
        public static readonly Uri ErrorApi = new Uri(Host, "/api/error");
        public static readonly Uri StartApi = new Uri(Host, "/api/start");

        internal readonly SqliteStringProducer ErrorDataProducer;
        private readonly HttpClient Network;
        public const int MaxNumQueuedCalls = 20;

        private int _lastDroppedReportsEpochTime = 0;
        private bool _queueCongestedAtLastReport = false;
        private int _congestedQueueWarningTimeout = 60;

        public Reporter(FileSystem storage, HttpClient network, string path, int congestedQueueWarningTimeout = 60)
        {
            Network = network;
            storage.NewDirAsync(path).RunSynchronously<Unit>();

            var dbPath = Path.Combine(path, "errorDb.sql");
            ErrorDataProducer = new SqliteStringProducer(dbPath, 2000000);

            IcloudBackup.Exclude(dbPath);
            GameId = "";
            _congestedQueueWarningTimeout = congestedQueueWarningTimeout;
        }

        public string GameId { get; set; }

        public Async<Unit> ReportStart(string payload, Information.Sbs sbsInfo, Information.App appInfo, string customUserId)
        {
            return StoreReport(StartApi, payload, sbsInfo, appInfo, customUserId);
        }

        public Async<Unit> ReportError(string payload, Information.Sbs sbsInfo, Information.App appInfo, string customUserId)
        {
            return StoreReport(ErrorApi, payload, sbsInfo, appInfo, customUserId);
        }

        public virtual void DeliverReportsInBackground()
        {
            DeliverReportsAsync().Start();
        }

        internal Async<Unit> DeliverReportsAsync()
        {
            return ErrorDataProducer.IsBeingConsumed()
                ? () => Unit.Default
                : ErrorDataProducer.Map<string, string, Unit>(SendReport).Ignore();
        }

        private Async<Unit> StoreReport(Uri endpoint, string payload, Information.Sbs sbsInfo, Information.App appInfo, string customUserId)
        {
            return () =>
            {
                if (ErrorDataProducer.AvailableCount() >= MaxNumQueuedCalls)
                {
#if !NOT_UNITY && UNITY_EDITOR
                    UnityEngine.Debug.Log("cannot store report (" + payload + ") for delivery to erroranalytics, because queue already contains " + MaxNumQueuedCalls + " pending calls");
#endif
                    // whenever we hit the queues limit and have not been congested before and at least _congestedQueueWarningTimeout passed, 
                    // send a congestion warning to EA otherwise drop the report
                    var currentEpochTime = Time.EpochTime();
                    if (!_queueCongestedAtLastReport && _lastDroppedReportsEpochTime + _congestedQueueWarningTimeout < currentEpochTime)
                    {
                        var e = new Payload.Event(
                            Time.EpochTime(),
                            ErrorAnalytics.LogSeverity.Warning,
                            customUserId,
                            this.GetType().ToString(),
                            "EA Queue has hit limit and starts dropping error reports",
                            appInfo,
                            "",
                            new ParsingUtility.StackTraceElement[] { },
                            new string[] { },
                            new Dictionary<string, object>(),
                            new Dictionary<string, object>()
                        );

                        var p = Payload.SerializeErrorPayload(sbsInfo, new[] { e });
                        _lastDroppedReportsEpochTime = currentEpochTime;
                        _queueCongestedAtLastReport = true;
                        return ErrorDataProducer.Produce(Report.Create(endpoint, p).Serialize()).RunSynchronously();
                    }
                    _queueCongestedAtLastReport = true;
                    _lastDroppedReportsEpochTime = currentEpochTime;
                    return Unit.Default;
                }
                _queueCongestedAtLastReport = false;
                return ErrorDataProducer.Produce(Report.Create(endpoint, payload).Serialize()).RunSynchronously();
            };
        }

        private Async<Maybe<Unit>> SendReport(string data)
        {
            return () =>
            {
                var report = Report.Create(data);
                var headers = new Dictionary<string, HttpHeader>();
                headers["X-SBS-ID"] = new HttpHeader("X-SBS-ID", GameId);

                var result = Network.Post(report.Endpoint, report.PayloadBytes(), headers.ToImmutableDictionary());
                Func<int, bool> errorIn500Range = x => x < 599 && x >= 500;
                return errorIn500Range((int)result.StatusCode) ? Maybe.Nothing<Unit>() : Maybe.Just(Unit.Default);
            };
        }

        internal struct Report
        {
            private static readonly Encoding Encoding = Encoding.UTF8;

            public static Report Create(Uri endpoint, string payload)
            {
                return new Report(endpoint.ToString(), payload);
            }

            public static Report Create(string data)
            {
                return JSON.Deserialize<Report>(data);
            }

            public readonly string Endpoint;
            public readonly string Payload;

            [JsonConstructor]
            private Report(string endpoint, string payload)
            {
                Payload = payload;
                Endpoint = endpoint;
            }

            public IEnumerable<byte> PayloadBytes()
            {
                return Encoding.GetBytes(Payload);
            }

            public string Serialize()
            {
                return JSON.Serialize(this);
            }
        }
    }
}
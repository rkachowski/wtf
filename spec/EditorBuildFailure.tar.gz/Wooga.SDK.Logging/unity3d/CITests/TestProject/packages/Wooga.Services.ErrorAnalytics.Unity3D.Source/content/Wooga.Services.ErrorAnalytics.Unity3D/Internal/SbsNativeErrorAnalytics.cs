﻿using UnityEngine;
using System.Runtime.InteropServices; // Keep this, it's used for iOS

namespace Wooga.Services.ErrorAnalytics
{
    internal class SbsNativeErrorAnalytics
    {
#if UNITY_IPHONE && !UNITY_EDITOR

        [DllImport ("__Internal")]
        public static extern void InitErrorTracking(string gameId, string userId);

        [DllImport ("__Internal")]
        public static extern void SetSBSDeviceId(string deviceId);

        [DllImport ("__Internal")]
        public static extern void SetSBSUserId(string userId);

        [DllImport ("__Internal")]
        public static extern void NotifyError(string errorType, string errorMessage, string stackTrace, string metaData, bool inBackground, int severity);

        [DllImport ("__Internal")]
        public static extern void SetBreadcrumbBufferSize (int size);

        [DllImport ("__Internal")]
        public static extern void AddBreadcrumb (string text);

		public static void Print (string text)
		{
			System.Console.WriteLine(text);
		}

        public static void InitErrorAnalytics (string gameId, string userId, Information.App appInfo) {
            InitErrorTracking(gameId, userId);
        }


#elif UNITY_ANDROID && !UNITY_EDITOR


        static AndroidJavaClass errorAnalyticsAndroid
        {
            get
            {
                if (_errorAnalyticsAndroid == null)
                {
                    _errorAnalyticsAndroid = new AndroidJavaClass("com.wooga.services.erroranalytics.facade.EAFacade");
                }
                return _errorAnalyticsAndroid;
            }
        }
        static AndroidJavaClass _errorAnalyticsAndroid = null;

        public static void InitErrorAnalytics (string gameId, string userId, Information.App appInfo)
        {
            AndroidJavaClass jcUnityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            errorAnalyticsAndroid.CallStatic("initErrorAnalytics", 
                jcUnityPlayer.GetStatic<AndroidJavaObject>("currentActivity"), 
                gameId, 
                userId,
                appInfo.Version,
                appInfo.TechnicalVersion,
                appInfo.BundleIdentifier
                );
        }

        public static void SetSBSDeviceId (string deviceId)
        {
            errorAnalyticsAndroid.CallStatic("setSBSDeviceId", deviceId);
        }

        public static void SetSBSUserId (string sbsUserId)
        {
            errorAnalyticsAndroid.CallStatic("setSBSUserId", sbsUserId);
        }

        public static void NotifyError (string errorClass, string errorMessage, string stackTrace, string metaData, bool inBackground, int severity)
        {
//			Print("NOTIFY ERROR!!!!!!!");
            //errorAnalyticsAndroid.CallStatic("NotifyError", errorClass, errorMessage, stackTrace, metaData, inBackground, severity);
        }

        public static void SetBreadcrumbBufferSize (int size)
        {
            errorAnalyticsAndroid.CallStatic("setBreadcrumbBufferSize", size);
        }

        public static void AddBreadcrumb (string text)
        {
            errorAnalyticsAndroid.CallStatic("addBreadcrumb", text);
        }

		public static void Print (string text)
		{
            //errorAnalyticsAndroid.CallStatic("Print", text);
		}



        //TODO set isInForeground

#else
        public static void InitErrorAnalytics(string gameId, string userId, Information.App appInfo)
        {
        }

        public static void SetSBSDeviceId(string deviceId)
        {
        }

        public static void SetSBSUserId(string userId)
        {
        }

        public static void NotifyError(string errorClass, string errorMessage, string stackTrace, string metaData,
            bool inBackground, int severity)
        {
        }

        public static void SetBreadcrumbBufferSize(int size)
        {
        }

        public static void AddBreadcrumb(string text)
        {
        }

        public static void Print(string text)
        {
            Debug.Log(text);
        }

#endif
    }
}
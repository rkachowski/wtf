# Unity ErrorAnalytics

Error reporting for Unity.

| Branch | Build Status |
|--------|--------------|
| master | [![Build Status](https://magnum.travis-ci.com/wooga/wdk-unity-ErrorAnalytics.svg?token=5jb3FABjFj3XsUQNgrf4&branch=master)](https://magnum.travis-ci.com/wooga/wdk-unity-ErrorAnalytics)|

[ApiDoc](http://ci.sdk.wooga.com:8080/job/wdk-unity-ErrorAnalytics/ws/documentation/index.html)

## Installation

The library is installed using the [WDK package management system](https://github.com/wooga/wdk-docs/wiki/Getting-started-with-Paket-Paket.Unity3D-package-management):
```
$ .paket/wooget.sh install Wooga.Services.ErrorAnalytics.Unity3D.Source
```

`Wooga.Services.ErrorAnalytics` depends on [Wooga.DeviceInfo](https://github.com/wooga/wdk-unity-DeviceInfo), which requires certain permissions on Android. Check the [Wooga.DeviceInfo Readme](https://github.com/wooga/wdk-unity-DeviceInfo) for more information.

## Setup

To initialize ErrorAnalytics, call Init with your SBS game id. Note that this method _must_ be called from the main thread.


## Known issues

Mono on iOS is *not* supported. Please use il2cpp instead.

Because Unity can only call native Java methods from its main thread, we can't send breadcrumbs from other Unity threads than the main thread to Java. This means that errors caught by the Java error handler will not contain breadcrumbs sent from a different thread than the main unity thread.
However, errors that occur while calling a Java method from Unity are usually caught by the _Unity_ error handler, which is able to report all breadcrumbs. The Java error handler is only needed when an asynchronous task in Java throws an error or if a signal is raised (e.g. a segmentation fault), since those errors can't be caught by the Unity error handler. So most of the time, all breadcrumbs should be displayed.



## Usage

The public API is accessed through the three static classes `ErrorAnalytics`, `Log` and `Assert`.

### Initialize

Error analytics should be initialized as early as possible with a call to

```csharp
ErrorAnalytics.Init(<you_sbs_game_id>);
```

from the *main thread* (e.g. `Awake` in the loading scene).

When the app returns from the background

```csharp
ErrorAnalytics.NotifyStart();
```

should be called.

### Optional parameters

If you are using the [`CoreServices`](https://github.com/wooga/wdk-unity-CoreServices) and are authenticated with SBS, you should add the SBS device and user id:
```csharp
ErrorAnalytics.UpdateSbsInfo(<sbs_device_id_string>, <sbs_user_id_string>);
```

Objects can be registered to be serialized to JSON and send along with the error message:
```csharp
ErrorAnalytics.RegisterObjectToSerialize("userData", userData);
ErrorAnalytics.UnregisterObjectToSerialize("userData");
```
Note that there is a size limit to the serialized JSON string.

You can set a function, which will be called in case an exception occured:
```csharp
ErrorAnalytics.SetExceptionCallback((ex) => {});
```
Breadcrumbs provide a way of logging important events in your game:
```csharp
ErrorAnalytics.AddBreadcrumb("SCENE STARTED");
```
A fixed amount of them is stored in a queue (first in, first out) and are send along with the error.

To each error tracking call, the unique device id from [`DeviceInfo`](https://github.com/wooga/wdk-unity-DeviceInfo) is added as identifier. While it is not recommended, you can change this primary id:
```csharp
ErrorAnalytics.UpdateCustomUserId("PetersTestIPhone");
```

### Logging

Infos, Warnings, Errors and Fatals can be reported via the `Log` static class, e.g.,

```csharp
Log.Error("Test Error via Log.Error", "Something went wrong", new Dictionary<string, object>() { {"foo", "bar"}, {"baz", "quux"} });
Log.InfoBreadcrumb("A breadcrumb added via Log.Info");
```

Calls to `Log.InfoBreadcrumb` are added to the breadcrumbs and are logged to the console in the editor or development builds.

Calls to `Log.Debug` are only logged to the console in the editor or development builds.

The meta data dictionary is serialized to JSON. The total size of the serialized JSON is limited (currently to 1500 characters). In case the serialization fails or the size is exceeded the meta data is replaced with a warning message.

### Assertions

`Assert` provides two simple assertions, which are logged to the backend in case of failure:

```csharp
Assert.Warning(1 > 2, "One is not larger than 2");
Assert.Fatal(1 < 2, "Something went really wrong, better exit the program");
```

While `Assert.Warning` will only report a warning to the backend, `Assert.Fatal` will throw an `AssertException`.

### Symbolication of the crash logs

Error analytics backend is capable to symbolicate the crash logs it receives, [see instructions here how to upload the dSYM files](https://github.com/wooga/sbs-error-tracking-api).

### Android Log clutter

If you see something like

```
D/Unity   (30483): > AndroidJNI_CUSTOM_ExceptionOccurred()
D/Unity   (30483): > AndroidJNI_CUSTOM_DeleteLocalRef()
D/Unity   (30483): > AndroidJNI_CUSTOM_DeleteLocalRef()
D/Unity   (30483): > AndroidJNI_CUSTOM_FromReflectedMethod()
D/Unity   (30483): > AndroidJNI_CUSTOM_ExceptionOccurred()
D/Unity   (30483): > AndroidJNI_CUSTOM_DeleteLocalRef()
D/Unity   (30483): > AndroidJNI_CUSTOM_NewStringUTF()
```

clutter your log on android, someone (for example the facebook library) has set AndroidJNIHelper.debug = true.
You can remove the clutter by setting it back to false, on the mainthread after the offender has set it.

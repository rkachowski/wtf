﻿using System;

namespace Wooga.Services.ErrorAnalytics
{
    public static class Assert
    {
        public static void Fatal(bool condition, string context = "")
        {
            if (!condition)
            {
                throw new AssertException(context);
            }
        }

        public static bool Warning(bool condition, string context = "")
        {
            if (!condition)
            {
                Log.Warning(new AssertException(context));
            }

            return condition;
        }

        public class AssertException : Exception
        {
            public AssertException(string context)
                : base("ASSERTION FAILED : " + context)
            {
            }
        }
    }
}
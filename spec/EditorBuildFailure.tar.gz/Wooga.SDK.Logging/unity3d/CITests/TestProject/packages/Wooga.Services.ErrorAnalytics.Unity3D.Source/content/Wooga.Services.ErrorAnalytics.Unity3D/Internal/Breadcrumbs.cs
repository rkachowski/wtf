﻿using System.Collections.Generic;

namespace Wooga.Services.ErrorAnalytics
{
    internal struct Breadcrumbs
    {
        private readonly Queue<string> _queue;
        private readonly int _size;

        public Breadcrumbs(int size)
        {
            _size = size;
            _queue = new Queue<string>(size);
        }

        public void Append(string crumb)
        {
            lock (_queue)
            {
                while (_queue.Count >= _size)
                {
                    _queue.Dequeue();
                }

                _queue.Enqueue(crumb);
            }
        }

        public string[] ToArray()
        {
            lock (_queue)
            {
                return _queue.ToArray();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Wooga.Services.ErrorAnalytics
{
    /// <summary>
    ///     Parsing utility for ErrorTracking service.
    ///     This is used to parse stacktraces and exception logs.
    /// </summary>
    internal static class ParsingUtility
    {
        public enum ParseType
        {
            EnvironmentStackTrace,
            LogStackTrace,
            UnhandledExceptionStackTrace,
            Exception
        }

        private static readonly Regex exceptionRegEx = new Regex(@"^(?<errorClass>.+?):\s*(?<message>.*)");

        private static readonly Regex regexEnvironmentStackTrace =
            new Regex(@"\s*at (?<method>\S+\([^\)]*\))( in (?<file>\S+):(line )?(?<line>\d+))?");

        private static readonly Regex regexGenericStackTrace =
            new Regex(@"^(?<method>\S+\s*\((?!at )[^\)]*\))(\s*(\(at (?<file>.+):(?<line>\d+)\)))?");

        public static List<StackTraceElement> ParseStackTraceElements(string stackTrace, ParseType type)
        {
            Regex rex = null;
            switch (type)
            {
                case ParseType.EnvironmentStackTrace:
                    rex = regexEnvironmentStackTrace;
                    break;
                case ParseType.LogStackTrace:
                    rex = regexGenericStackTrace;
                    break;
                case ParseType.UnhandledExceptionStackTrace:
                    rex = regexGenericStackTrace;
                    break;
            }

            var lines = stackTrace.Split("\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            var elements = new List<StackTraceElement>();

            var i = 0;

            for (; i < lines.Length; i++)
            {
                var line = lines[i];

                var match = rex.Match(line);

                if (match.Success)
                {
                    var element = new StackTraceElement();
                    element.file = match.Groups["file"].Value;
                    if (match.Groups["line"].Value != "")
                    {
                        element.lineNumber = int.Parse(match.Groups["line"].Value);
                    }
                    element.method = match.Groups["method"].Value;

                    elements.Add(element);
                }
            }

            return elements;
        }

        public static ParsedException ParseExceptionLog(string exceptionLog, ErrorAnalytics.LogSeverity severity)
        {
            var ex = new ParsedException();
            var match = exceptionRegEx.Match(exceptionLog);

            if (match.Success)
            {
                ex.errorClass = match.Groups["errorClass"].Value;
                ex.errorMessage = match.Groups["message"].Value.Trim();
            }
            //TODO how the hell does this work? What does it do? Add tests for this and document the behavior
            else if (exceptionLog.Length < Constants.MaxParseableExceptionLogSize)
            {
                ex.errorClass = exceptionLog;
            }
            else
            {
                ex.errorClass = severity.ToString();
                ex.errorMessage = exceptionLog;
            }

            return ex;
        }

        public class StackTraceElement
        {
            public int columnNumber = -1;
            public string file;
            public bool inProject;
            public int lineNumber = -1;
            public string method;

            public StackTraceElement(string file, int lineNumber, int columnNumber, string method, bool inProject)
            {
                this.file = file;
                this.lineNumber = lineNumber;
                this.columnNumber = columnNumber;
                this.method = method;
                this.inProject = inProject;
            }

            public StackTraceElement()
            {
            }

            public override string ToString()
            {
                return string.Format("StackTraceElement. File: {0}, ln: {1}, cl: {2}, method: {3}, inProject: {4}", file,
                    lineNumber, columnNumber, method, inProject);
            }

            public override int GetHashCode()
            {
                return base.GetHashCode();
            }

            public override bool Equals(object obj)
            {
                if (!(obj is StackTraceElement))
                {
                    return false;
                }

                var other = obj as StackTraceElement;
                return file == other.file
                       && lineNumber == other.lineNumber
                       && columnNumber == other.columnNumber
                       && method == other.method
                       && inProject == other.inProject;
            }
        }
    }

    public class ParsedException
    {
        public string errorClass;
        public string errorMessage;
        public string stackTrace;
		public string uuid;
    }
}
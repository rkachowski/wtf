﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

#if !NOT_UNITY
using UnityEngine;
#endif

namespace Wooga.DeviceInfo.Unity3D
{
    static public class Platform
    {
#if (UNITY_IOS || UNITY_IPHONE) && !UNITY_EDITOR
        [DllImport ("__Internal")]
        static extern bool WoogaDeviceInfoIsJailbroken();
#endif
        public static bool isJailbroken()
        {
#if (UNITY_IOS || UNITY_IPHONE) && !UNITY_EDITOR
            return WoogaDeviceInfoIsJailbroken();
#endif
            return false;
        }


        public static List<String> InstalledWoogaBundleIds()
        {
            var result = new List<String>();

#if UNITY_ANDROID && !UNITY_EDITOR
            AndroidJavaClass up = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject ca = up.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject packageManager = ca.Call<AndroidJavaObject>("getPackageManager");

            var flags = new System.Object[] {0};
            AndroidJavaObject applicationInfoList = packageManager.Call<AndroidJavaObject>("getInstalledApplications", flags);
            Regex r = new Regex("^(com|net)\\.wooga\\.|^net\\.mantisshrimp\\.", RegexOptions.IgnoreCase);
            int count = applicationInfoList.Call<int>("size");
            for (int i = 0; i < count; i++)
            {
                var app = applicationInfoList.Call<AndroidJavaObject>("get", i);
                String packageName = app.Get<String>("packageName");
                if(r.Match(packageName).Success)
                {
                    result.Add(packageName);
                }
            }
#endif
            return result;
        } 
    }
}

typedef void (*WGMEMCALLBACK)();

@interface WGMemoryWarningDelegate : NSObject

@property (nonatomic) WGMEMCALLBACK callback;

- (id) init;
- (void) receivedMemoryWarning:(NSNotification *) NSNotification;
- (void) setCallback:(WGMEMCALLBACK) callback;

@end

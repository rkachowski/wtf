﻿using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using UnityEngine;

namespace Wooga.DeviceInfo
{
	static public class BootTime
	{
#if (UNITY_IOS || UNITY_IPHONE) && !UNITY_EDITOR
		[DllImport("__Internal")]
		static extern long WoogaDeviceInfoGetBootTime();
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
        static Regex _androidBootTimeRegEx = new Regex(@"btime (?<btime>\d+)");
#endif

        public static long GetBootTime ()
		{
#if (UNITY_IOS || UNITY_IPHONE) && !UNITY_EDITOR

			return WoogaDeviceInfoGetBootTime();

#elif UNITY_ANDROID && !UNITY_EDITOR

			long boottime = 0;
			try {				
				var procData = System.IO.File.ReadAllText ("/proc/stat");

				if (_androidBootTimeRegEx.IsMatch (procData))
				{
					boottime = long.Parse (_androidBootTimeRegEx.Match (procData).Groups ["btime"].Value);
				}
			}
			catch (System.Exception ex)
			{
				Debug.LogWarning("NATIVE HELPER : FAILED TO READ BOOTTIME " + ex);
			}

			return boottime;
			
#else

            return 0;

#endif
		}
	}
}

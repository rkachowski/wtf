#import "WGMemoryWarningDelegate.h"

@implementation WGMemoryWarningDelegate

-(void) dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (id) init
{
    self = [super init];
    if (!self) return nil;

    [[NSNotificationCenter defaultCenter] addObserver:self
        selector:@selector(receivedMemoryWarning:)
        name:@"UIApplicationDidReceiveMemoryWarningNotification"
        object:nil];

    return self;
}

- (void) receivedMemoryWarning:(NSNotification *) notification
{
    if(_callback)
    {
        _callback();
    }
}

@end

WGMemoryWarningDelegate *delegate;

void _setMemoryCallback(WGMEMCALLBACK callback)
{
    [delegate setCallback:callback];
}

void _initializeMemoryDelegate()
{
    delegate = [[WGMemoryWarningDelegate alloc] init];
}


void _triggerMemoryWarning()
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"UIApplicationDidReceiveMemoryWarningNotification" object:nil userInfo:nil];
}

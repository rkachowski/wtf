﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Wooga.Lambda.Data;
using Wooga.ThreadSafe.Async;
using System.Runtime.InteropServices;
using Wooga.Lambda.Control.Concurrent;

namespace Wooga.DeviceInfo.Unity3D
{
    class MemoryWarningDelegate
    {
        public delegate void MemoryCb();
        private static Action _warningCallback;
        private static bool _initialized = false;
        
#if UNITY_IOS && !UNITY_EDITOR
        [DllImport("__Internal")]
        private static extern void _initializeMemoryDelegate();                
        [DllImport ("__Internal")]
		public static extern void _setMemoryCallback(MemoryCb callback);
#else
        private static void _initializeMemoryDelegate() { }        
		public static void _setMemoryCallback(MemoryCb callback) { }
#endif
        

        /// <summary>
        /// Set an action to be invoked when a memory warning notification is recieved on iOS
        /// </summary>
        /// <param name="callback">The callback to invoke, will be called on main thread</param>
        public static void SetCallback(Action callback)
        {
            if(!_initialized) Init();

            _warningCallback = callback;
        }

        /// <summary>
        /// Creates the object that listens for memory warning notifications
        /// </summary>
        public static void Init()
        {
            if (_initialized) return;

            _initializeMemoryDelegate();
            _setMemoryCallback(new MemoryCb(OnWarning));
            _initialized = true;
        }

        [MonoPInvokeCallback (typeof (MemoryCb))]
        private static void OnWarning()
        {
            if (_warningCallback != null)
            {
                AsyncExtensions.OnMainThread(() =>
                {
                    _warningCallback();
                    return Unit.Default;
                }).RunSynchronously();
            }
        }
    }
    
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class MonoPInvokeCallbackAttribute : Attribute
    {
        public MonoPInvokeCallbackAttribute(Type t) { }
    }
}

﻿using UnityEngine;
using System.Collections;
using System;
using System.Runtime.InteropServices;
using System.Net;

namespace Wooga.DeviceInfo
{
    static public class Proxy
    {
#if UNITY_IPHONE && !UNITY_EDITOR
        
        // @see http://stackoverflow.com/a/13693988/957370

        [DllImport ("__Internal")]
        public static extern string WoogaDeviceInfoGetProxyHost();

        [DllImport ("__Internal")]
        public static extern int WoogaDeviceInfoGetProxyPort();

        public static string GetHost() 
        {
            return WoogaDeviceInfoGetProxyHost();
        }

        public static int GetPort() 
        {
            return WoogaDeviceInfoGetProxyPort();
        }

        public static string GetExclusionList() 
        {
            return "NotImplemented";
        }
        
#elif UNITY_ANDROID && !UNITY_EDITOR
        
        static AndroidProxySettings getProxySettings()
        {
            AndroidJavaClass jcUnityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject activity = jcUnityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
			var _javaproxySettings = new AndroidJavaObject("com.wooga.deviceinfo.proxy.ProxySettings", activity); 
										
			var proxySettings = new AndroidProxySettings(); 

			if(_javaproxySettings != null)
			{
				proxySettings.Host = _javaproxySettings.Call<string>("getHost");
				proxySettings.Port = _javaproxySettings.Call<int>("getPort");
				proxySettings.ExclusionList = _javaproxySettings.Call<string>("getExclusionList");
			}

			return proxySettings;
        }

		static AndroidProxySettings proxySettings = null;

        private static void ensureProxySettings()
        {
            if(proxySettings == null){
				proxySettings = getProxySettings();
			}
        }

        public static string GetHost() 
        {
		    ensureProxySettings();
			return proxySettings.Host;
        }

        public static int GetPort() 
        {
            ensureProxySettings();
            return proxySettings.Port;
        }

        public static string GetExclusionList() 
        {
            ensureProxySettings();
            return proxySettings.ExclusionList;
        }
        
#else

        public static string GetHost()
        {
            return "";
        }

        public static int GetPort()
        {
            return 0;
        }

        public static string GetExclusionList()
        {
            return "";
        } 

#endif

        public static WebProxy GetWebProxy()
        {
            var host = GetHost();
            var port = GetPort();

            if (host == "" || port == 0 || port == -1)
            {
                return null;                
            }

            WebProxy nativeProxy = new WebProxy();
            nativeProxy.Address = new Uri("http://" + host + ":" + port);

            return nativeProxy;
        }

        public static void SetGlobalDefaultProxy()
        {
            var proxy = Proxy.GetWebProxy();

            if (proxy != null)
            {
                WebRequest.DefaultWebProxy = proxy;
            }
        }

#if UNITY_ANDROID && !UNITY_EDITOR
        internal class AndroidProxySettings
        {
            public string Host;
            public int Port;
            public string ExclusionList;
        }
#endif
    }
}
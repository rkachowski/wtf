﻿using System.Runtime.InteropServices;
using UnityEngine;

namespace Wooga.DeviceInfo
{
    static public class Bundle
    {
        public static string version
        {
            get
            {
                if (_version == null)
                {
                    Init();
                }

                return _version;
            }
        }
        static string _version;

        public static string identifier
        {
            get
            {
                if (_identifier == null)
                {
                    Init();
                }

                return _identifier;
            }
        }
        static string _identifier;

        public static string build
        {
            get
            {
                if (_build == null)
                {
                    Init();
                }

                return _build;
            }
        }
        static string _build;

#if (UNITY_IOS || UNITY_IPHONE) && !UNITY_EDITOR

        [DllImport("__Internal")]
        public static extern string WoogaDeviceInfoGetCFBundleVersion();

        [DllImport("__Internal")]
        public static extern string WoogaDeviceInfoGetBuildVersion();

        [DllImport("__Internal")]
        public static extern string WoogaDeviceInfoGetCFBundleIdentifier();

        public static void Init()
        {
            _version = WoogaDeviceInfoGetCFBundleVersion();
            _identifier = WoogaDeviceInfoGetCFBundleIdentifier();
            _build = WoogaDeviceInfoGetBuildVersion();
        }

#elif UNITY_ANDROID && !UNITY_EDITOR

        public static void Init()
        {
            try
            {
                AndroidJavaClass contextCls = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                AndroidJavaObject context = contextCls.GetStatic<AndroidJavaObject>("currentActivity"); 
                AndroidJavaObject packageMngr = context.Call<AndroidJavaObject>("getPackageManager");
                string packageName = context.Call<string>("getPackageName");
                AndroidJavaObject packageInfo = packageMngr.Call<AndroidJavaObject>("getPackageInfo", packageName, 0);

                _version = packageInfo.Get<string>("versionName");
                _identifier = packageName;
                _build = packageInfo.Get<int>("versionCode").ToString();
            }
            catch
            {
                _version = "";
                _identifier = "";
                _build = "";
            }
        }

#else

        public static void Init()
        {
            _version = "0.0.0";
            _identifier = "com.wooga.test";
            _build = "0";
        }

#endif
    }
}

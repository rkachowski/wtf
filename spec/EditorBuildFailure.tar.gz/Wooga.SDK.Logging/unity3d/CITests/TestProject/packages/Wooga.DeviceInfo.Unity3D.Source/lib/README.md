# Unity DeviceInfo

Native device info, e.g., cross app device id.

[![Build Status](https://magnum.travis-ci.com/wooga/wdk-unity-DeviceInfo.svg?token=5jb3FABjFj3XsUQNgrf4&branch=master)](https://magnum.travis-ci.com/wooga/wdk-unity-DeviceInfo) (Dummy tests only)

## Cross app id

### iOS

On iOS the uniqueid is generated using native code (see https://github.com/wooga/wooga-deviceid-ios).
Objc classes are included in the project and placed in Plugins/iOS folder do not move or rename this folder.

### Android

On Android the uniqueid is generated as 

7778 + hashOf(${ANDROID_ID}${MAC_ADDRESS}:${DEVICE_NAME}' running Apportable')

As the app requires ACCESS_WIFI_STATE we need a custom AndroidManifesto.xml that is placed under Plugins/Android. Do not move or rename this folder.

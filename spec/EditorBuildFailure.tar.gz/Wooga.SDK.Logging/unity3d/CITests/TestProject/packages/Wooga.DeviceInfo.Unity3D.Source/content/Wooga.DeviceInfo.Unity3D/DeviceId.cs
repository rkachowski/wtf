﻿using System;
using System.Security.Cryptography;
using UnityEngine;

namespace Wooga.DeviceInfo
{
    static public class DeviceId
    {
        public static string uniqueIdentifier
        {
            get
            {
                if (_uniqueIdentifier == null)
                {
                    _uniqueIdentifier = NativeUniqueIdentifier();
                }

                return _uniqueIdentifier;
            }
        }
        static string _uniqueIdentifier;
#if NOT_UNITY

        static string NativeUniqueIdentifier()
        {
            return "fake_device_id";
        }

#elif (UNITY_IOS || UNITY_IPHONE) && !UNITY_EDITOR

        [System.Runtime.InteropServices.DllImport("__Internal")]
        extern static string WoogaDeviceInfoGetMacAddress();

        [System.Runtime.InteropServices.DllImport("__Internal")]
        extern static string WoogaDeviceInfoGetDeviceName();

        [System.Runtime.InteropServices.DllImport("__Internal")]
        extern static string WoogaDeviceInfoGetIdForVendor();

        [System.Runtime.InteropServices.DllImport("__Internal")]
        extern static float WoogaDeviceInfoGetSystemVersion();

        static string NativeUniqueIdentifier()
        {
            float iosVersion = WoogaDeviceInfoGetSystemVersion();
            int prefix = iosVersion >= 7.0 ? 6767 : 6667;
            string hashSource = iosVersion >= 7.0
                ? WoogaDeviceInfoGetIdForVendor()
                : WoogaMacAddressBasedId();
            return HashIdentifier(prefix, hashSource);
        }

	    private static string WoogaMacAddressBasedId()
	    {
	        return String.Format("{0}:{1}", WoogaDeviceInfoGetMacAddress(), WoogaDeviceInfoGetDeviceName());
	    }

#elif UNITY_ANDROID && !UNITY_EDITOR

        static string NativeUniqueIdentifier()
        {
            return AndroidUniqueIdentifierCached();
        }

        static string AndroidUniqueIdentifierCached()
        {
            string deviceIdKey = "Wooga.Device.UniqueAndroidDeviceId";

			if (PlayerPrefs.HasKey(deviceIdKey)) {
                return PlayerPrefs.GetString(deviceIdKey);
            } else {
                string deviceId = AndroidUniqueIdentifier();
                PlayerPrefs.SetString(deviceIdKey, deviceId);
                return deviceId;
            }
        }

        static string AndroidUniqueIdentifier()
        {
            // to compute the identifier for android
            // 7778${ANDROID_ID}${MAC_ADDRESS}:${DEVICE_NAME}' running Apportable'

            string deviceName = AndroidDeviceModel() + " running Apportable"; // lagacy
            string stringToHash = AndroidId() + AndroidMacAddress() + ":" + deviceName;
            Debug.Log("andoid id, hashing: " + stringToHash);

            return HashIdentifier(7778, stringToHash);
        }

        static string _androidId = null;
        public static string AndroidId()
        {
            if(_androidId != null) return _androidId;

            AndroidJavaClass clsUnity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject objActivity = clsUnity.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject objResolver = objActivity.Call<AndroidJavaObject>("getContentResolver");

            AndroidJavaClass clsSecure = new AndroidJavaClass("android.provider.Settings$Secure");
            string ANDROID_ID = clsSecure.GetStatic<string>("ANDROID_ID");
            string androidId = clsSecure.CallStatic<string>("getString", objResolver, ANDROID_ID);
            Debug.Log("android id " + androidId);

            _androidId = androidId;
            return _androidId;
        }

		static string AndroidDeviceModel()
		{
			AndroidJavaClass clsBuild = new AndroidJavaClass("android.os.Build");
			return clsBuild.GetStatic<string>("MODEL");
		}

        static string _androidManufacturer = null;
        public static string AndroidManufacturer()
		{
            if(_androidManufacturer == null){
                AndroidJavaClass clsBuild = new AndroidJavaClass("android.os.Build");
			    _androidManufacturer = clsBuild.GetStatic<string>("MANUFACTURER");
            }
            return _androidManufacturer;
		}

        static string _androidModel = null;
        public static string AndroidModel()
		{
            if(_androidModel == null){
                AndroidJavaClass clsBuild = new AndroidJavaClass("android.os.Build");
			    _androidModel = clsBuild.GetStatic<string>("MODEL");
            }
            return _androidModel;
		}

        static string _androidDeviceCode = null;
        public static string AndroidDeviceCode()
		{
            if(_androidDeviceCode == null){
                AndroidJavaClass clsBuild = new AndroidJavaClass("android.os.Build");
			    _androidDeviceCode = clsBuild.GetStatic<string>("DEVICE");
            }
            return _androidDeviceCode;
		}

        static int _androidApiLevel = 0;
        public static int AndroidApiLevel()
		{
            if(_androidApiLevel == 0){
				var clsBuild = AndroidJNI.FindClass("android/os/Build$VERSION");
				var fieldID = AndroidJNI.GetStaticFieldID(clsBuild, "SDK_INT", "I");
				_androidApiLevel = AndroidJNI.GetStaticIntField(clsBuild, fieldID);
            }
            return _androidApiLevel;
		}

        static string AndroidMacAddress()
        {
            AndroidJavaObject mWiFiManager;

            using (AndroidJavaObject activity = new AndroidJavaClass("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity"))
            {
                mWiFiManager = activity.Call<AndroidJavaObject>("getSystemService", "wifi");
            }
            return mWiFiManager.Call<AndroidJavaObject>("getConnectionInfo").Call<string>("getMacAddress");
        }

#else
        static string NativeUniqueIdentifier()
        {
            return HashIdentifier(1111, SystemInfo.deviceUniqueIdentifier); // prefix 1111 is used to identify calls coming from the editor
        }
#endif

        static string HashIdentifier(int prefix, string addressAndDeviceName)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(addressAndDeviceName);
            byte[] hash = md5.ComputeHash(inputBytes);
            ulong strippedMD548bit =
                (ulong)hash[0] |
                (ulong)hash[1] << 8 |
                (ulong)hash[2] << 16 |
                (ulong)hash[3] << 24 |
                (ulong)hash[4] << 32 |
                (ulong)hash[5] << 40;

            // add prefix
            strippedMD548bit += ((ulong)prefix * (ulong)1000000000000000L);

            return strippedMD548bit.ToString();
        }
    }
}

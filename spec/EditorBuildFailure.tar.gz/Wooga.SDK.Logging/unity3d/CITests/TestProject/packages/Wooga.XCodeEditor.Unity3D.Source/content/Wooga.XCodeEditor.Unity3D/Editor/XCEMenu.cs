﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using Wooga.XCodeEditor.Unity3D.XCodeEditor.Editor;

namespace Wooga.XCodeEditor.Unity3D.XCodeEditor.Editor
{
    public class XCEMenu
    {
        [MenuItem("Wooga/WDK/XCodeEditor/Enable", false, 52)]
        static void EnableXCE()
        {
            XCodeEditor.Disabled = false;
        }

        [MenuItem("Wooga/WDK/XCodeEditor/Disable", false, 53)]
        static void DisableXCE()
        {
            XCodeEditor.Disabled = true;
        }


        #region validation methods
        [MenuItem("Wooga/WDK/XCodeEditor/Enable", true)]
        static bool validate_EnableXCE()
        {
            return XCodeEditor.Disabled == true;
        }

        [MenuItem("Wooga/WDK/XCodeEditor/Disable", true)]
        static bool validate_DisableXCE()
        {
            return XCodeEditor.Disabled == false;
        }
        #endregion
    }
}
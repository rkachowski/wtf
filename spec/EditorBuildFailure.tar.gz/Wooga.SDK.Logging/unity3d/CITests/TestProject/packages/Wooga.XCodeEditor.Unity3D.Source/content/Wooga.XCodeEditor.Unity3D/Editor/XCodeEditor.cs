﻿using System;
using System.IO;
using UnityEngine;
using UnityEditor;
using UnityEditor.Callbacks;
using Wooga.Foundation.Json;
using Wooga.UnityEditor.iOS.Xcode;
using System.Collections.Generic;
using System.Linq;
using Log = Wooga.Foundation.Tools.Log;

namespace Wooga.XCodeEditor.Unity3D.XCodeEditor.Editor
{

    public static class XCodeEditor
    {
        /// <summary>
        /// Disable post processing functionality
        /// </summary>
        public static bool Disabled = false;

        private static BuildTarget iosTarget = BuildTarget.iOS;

        [PostProcessBuild]
        public static void OnPostProcessBuild(BuildTarget target, string projectRootPath)
        {
#if !UNITY_EDITOR
            return;
#endif
            if (Disabled || target != iosTarget)
                return;

            AssertIL2CPP();

            try
            {
                ModifyProject(projectRootPath);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }

        #region Project Modification

        private static void ModifyProject(string projectRootPath)
        {
            Log.Info("Start PostProcessing");

            var project = new PBXProject();
            Log.Info("loading project from " + PBXProject.GetPBXProjectPath(projectRootPath));

            //ReadFromFile will throw an exception if project is invalid / not found
            project.ReadFromFile(PBXProject.GetPBXProjectPath(projectRootPath));

            var files = GetModFiles();
            foreach (var file in files)
            {
                Log.Info("Applying " + Path.GetFileName(file));
                ApplyMod(file, project, projectRootPath);
            }


            File.WriteAllText(PBXProject.GetPBXProjectPath(projectRootPath), project.WriteToString());

            Log.Info("pbxproj file written successfully");
            Log.Info("End PostProcessing");
        }

        private static String[] GetModFiles()
        {
            // Find and run through all projmods files to patch the project
            var files = Directory.GetFiles(Application.dataPath, "*.projmods", SearchOption.AllDirectories);
            if (files.Length > 0)
            {
                Log.Warning("Found " + files.Length + " projmods files, these will be deprecated in future release");
            }

            var woogaMods = Directory.GetFiles(Application.dataPath, "*.woogamods", SearchOption.AllDirectories);

            Log.Info("Found " + woogaMods.Length + " *.woogamods");

            return files.Concat(woogaMods).ToArray();
        }

        private static void ApplyMod(string file, PBXProject project, string projectRootPath)
        {
            string target = project.TargetGuidByName(PBXProject.GetUnityTargetName());
            var mods = JSON.Deserialize(File.ReadAllText(file));

            AddSystemFrameworks(project, mods, target);
            AddDirectoriesAndFiles(project, projectRootPath, mods, target);
            ApplyBuildSettings(project, mods, target);
            ApplyInfoPlistModifications(project, mods, projectRootPath, target);
        }

        private static void ApplyInfoPlistModifications(PBXProject project, JSONNode mods, string projectRootPath,
            string target)
        {
            if (mods.HasKey("plist"))
            {
                var plistFile = new PlistDocument();
                var pathToPlist = Path.Combine(projectRootPath, "Info.Plist");
                plistFile.ReadFromFile(pathToPlist);

                var plistMods = mods.GetNode("plist").AsDictionary();
                foreach (KeyValuePair<string, JSONNode> setting in plistMods)
                {
                    var settingName = setting.Key;
                    var settingValue = setting.Value;

                    if (settingValue.IsCollection())
                    {
                        var settingArray = settingValue.AsCollection();
                        var plistArray = GetPlistArray(plistFile, settingName);

                        foreach (var projModSetting in settingArray)
                        {
                            string settingString = projModSetting.AsString();
                            Log.Info("Adding value " + settingString + " to section " + settingName + " in Info.plist");
                            plistArray.AddString(settingString);
                        }
                    }
                    else if (settingValue.IsBoolean())
                    {
                        plistFile.root.SetBoolean(settingName, settingValue.AsBoolean());
                    }
                    else if (settingValue.IsString())
                    {
                        plistFile.root.SetString(settingName, settingValue.AsString());
                    }
                    else if (settingValue.IsInt())
                    {
                        plistFile.root.SetInteger(settingName, settingValue.AsInt());
                    }
                    else
                    {
                        throw new NotImplementedException("Type of " + settingName +
                                                          " isn't supported for adding to plist");
                    }
                }

                Log.Info("Writing out " + pathToPlist);
                plistFile.WriteToFile(pathToPlist);
            }
        }

        private static PlistElementArray GetPlistArray(PlistDocument plistFile, string settingName)
        {
            PlistElementArray result = null;
            var node = plistFile.root[settingName];
            if (node == null)
            {
                result = plistFile.root.CreateArray(settingName);
            }
            if (node is PlistElementArray)
            {
                result = node as PlistElementArray;
            }

            return result;
        }

        /// <summary>
        /// Apply arbitrary build settings to project file
        /// </summary>
        private static void ApplyBuildSettings(PBXProject project, JSONNode mods, string target)
        {
            var buildSettings = mods.GetNode("buildSettings").AsDictionary();
            foreach (KeyValuePair<string, JSONNode> setting in buildSettings)
            {
                var settingName = setting.Key;
                var settingValue = setting.Value;

                if (settingValue.IsCollection())
                {
                    var collection = settingValue.AsCollection();
                    foreach (JSONNode node in collection)
                    {
                        project.AddBuildProperty(target, settingName, node.AsString());
                    }
                }
                else
                {
                    project.AddBuildProperty(target, settingName, settingValue.AsString());
                }
            }

            //always add wooga dir to search paths
            project.AddBuildProperty(target, "FRAMEWORK_SEARCH_PATHS", "$(PROJECT_DIR)/WoogaSDKFiles");
        }

        /// <summary>
        /// Adds all files + directories specified in projmods file
        /// </summary>
        private static void AddDirectoriesAndFiles(PBXProject project, string projectRootPath, JSONNode mods,
            string target)
        {
            var files = mods["files"].AsCollection();
            var directories = mods["folders"].AsCollection();
            foreach (var directory in directories)
            {
                files.Add(directory);
            }

            foreach (var itemToAdd in files)
            {
                var filename = itemToAdd.AsString();
                var flags = new List<string>();


                var filenameContainsCompileFlags = filename.IndexOf(":") != -1;
                if (filenameContainsCompileFlags)
                {
                    //getting compile flags
                    var split = filename.Split(':');
                    filename = split[0];

                    var flagsWithSpaces = split[1];
                    flags = flagsWithSpaces.Split(' ').ToList();
                }

                var sourcePath = Path.Combine("Assets/Plugins/iOS", filename);
                var projectDestinationPath = Path.Combine("WoogaSDKFiles", filename);
                var absoluteDestinationPath = Path.Combine(projectRootPath, projectDestinationPath);

                //remove from project file if auto imported by unity so we can re-add with flags
                TryRemoveFromProject(project, target, Path.Combine("Libraries/Plugins/iOS", filename));

                Log.Info("copying " + sourcePath + " to " + projectDestinationPath + " with flags " +
                       string.Join(",", flags.ToArray()));

                if (Directory.Exists(sourcePath))
                {
                    CopyAndReplaceDirectory(sourcePath, absoluteDestinationPath);
                }
                else
                {
                    CopyAndReplaceFile(sourcePath, absoluteDestinationPath);
                }

                var fileGUID = project.AddFile(projectDestinationPath, projectDestinationPath);

                //unity 5 will link frameworks automatically, so adding framework files 
                //to the build will result in duplicate entries in xcode's "Link Build with Libraries" phase...
                var shouldAddFileToBuild = filename.IndexOf(".framework") == -1;

                if (shouldAddFileToBuild)
                {
                    project.AddFileToBuild(target, fileGUID);
                }

                project.SetCompileFlagsForFile(target, fileGUID, flags);
            }
        }

        /// <summary>
        /// Removes a file from xcode project if it is found via project path
        /// </summary>
        /// <param name="project">project to remove from</param>
        /// <param name="target">target guid to remove from</param>
        /// <param name="sourcePath">project path to the file to remove</param>
        private static void TryRemoveFromProject(PBXProject project, string target, string sourcePath)
        {
            var existingGuid = project.FindFileGuidByProjectPath(sourcePath);
            if (!String.IsNullOrEmpty(existingGuid))
            {
                Log.Info("Removing auto imported file " + sourcePath);
                project.RemoveFileFromBuild(target, existingGuid);
            }
        }

        /// <summary>
        /// Adds an iOS framework to the build (installed in /System/Library/Frameworks)
        /// </summary>
        private static void AddSystemFrameworks(PBXProject project, JSONNode mods, string target)
        {
            var frameworks = mods["frameworks"].AsCollection();
            foreach (var framework in frameworks)
            {
                var frameworkName = framework.AsString();
                Log.Info("adding " + frameworkName);
                project.AddFrameworkToProject(target, frameworkName, false);
            }
        }

        #endregion


        #region File Manipulation

        private static void CopyAndReplaceDirectory(string srcPath, string dstPath)
        {
            if (Directory.Exists(dstPath))
            {
                Directory.Delete(dstPath);
            }

            if (File.Exists(dstPath))
            {
                File.Delete(dstPath);
            }

            Directory.CreateDirectory(dstPath);

            foreach (var file in Directory.GetFiles(srcPath))
            {
                File.Copy(file, Path.Combine(dstPath, Path.GetFileName(file)));
            }

            foreach (var dir in Directory.GetDirectories(srcPath))
            {
                CopyAndReplaceDirectory(dir, Path.Combine(dstPath, Path.GetFileName(dir)));
            }
        }

        private static void CopyAndReplaceFile(string srcPath, string dstPath)
        {
            if (Directory.Exists(dstPath))
            {
                Directory.Delete(dstPath);
            }

            if (File.Exists(dstPath))
            {
                File.Delete(dstPath);
            }

            Directory.CreateDirectory(Path.GetDirectoryName(dstPath));
            File.Copy(srcPath, dstPath);
        }

        #endregion

        private static void AssertIL2CPP()
        {
            ScriptingImplementation backend = (ScriptingImplementation)PlayerSettings.GetPropertyInt("ScriptingBackend", BuildTargetGroup.iOS);
            if (backend != ScriptingImplementation.IL2CPP)
            {
                var message =
                    "The scripting backend must be set to IL2CPP in order to avoid JIT / AOT errors when using WDK libs on iOS. It is currently set to " +
                    backend.ToString() +
                    ".\nPlease recompile with IL2CPP enabled unless this is intentional.";

                EditorUtility.DisplayDialog("IL2CPP not selected", message, "Ok", "Cancel");
            }
        }
    }
}


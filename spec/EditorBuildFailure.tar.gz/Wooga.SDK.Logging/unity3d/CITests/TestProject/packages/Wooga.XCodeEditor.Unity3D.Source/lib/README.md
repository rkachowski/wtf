# wdk-unity-XCodeEditor

## How to use

Add a `.projmods` file to a project in such a way that it will end up in an Editor subdir in the unity application.

This lib will search for all these files and apply them incrementally

Compiler flags can be added to a file via the format `CoolFilename.m:-fno-objc-arc -fa-cool-flag -fwhite-space-separated`
Files are expected to be found relative to `Assets/Plugins/iOS` in the unity project

```json
{
    "group": "Services",
    "libs": [],
    "frameworks": ["add iOS system frameworks here", "StoreKit.framework"],
    "headerpaths": [],
    "files": ["custom frameworks here","SBSErrorTracking.framework"
    "also files with compiler flags", "StupidCFFile.m:-fno-objc-arc"],
    "folders": [],
    "excludes": ["^.*.DS_Store$","^.*.meta$", "^.*.mdown^", "^.*.pdf$", "^.*.svn$"],
    "plist":{
        "plist key name":["hey i'm a string", "only support strings right now.."]
    },
    "buildSettings":
    {
        "OTHER_LDFLAGS": ["-ObjC", "-lstdc++"],
        "GCC_ENABLE_OBJC_EXCEPTIONS": "YES",
        "GCC_PREPROCESSOR_DEFINITIONS": ["NS_BLOCK_ASSERTIONS=1"],
        "ENABLE_NS_ASSERTIONS": "NO",
        "ENABLE_BITCODE":  "NO"
    }
}
```

## When to use
* You want to add compiler flags to a specific file
* You want the generated xcode project to contain custom build settings
    * `"OTHER_LDFLAGS": ["-ObjC", "-lstdc++"]`
    * `"ENABLE_BITCODE":  "NO"`
* You want to add a custom framework or dylib to the generated project

Otherwise unity will automatically import platform files found in `Assets/Plugins/iOS`



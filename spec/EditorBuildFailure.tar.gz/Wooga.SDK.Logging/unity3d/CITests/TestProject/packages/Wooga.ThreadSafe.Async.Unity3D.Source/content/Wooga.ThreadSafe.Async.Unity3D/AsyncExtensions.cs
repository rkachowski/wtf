﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Wooga.Lambda.Data;
using Wooga.Lambda.Control.Concurrent;
using System.Threading;

namespace Wooga.ThreadSafe.Async
{
    public static class AsyncExtensions
    {
        public static Async<T> OnMainThread<T>(this Async<T> m)
        {
            return () =>
            {
                // we could avoid some duplication when wrapping in yet another lambda:
                //Scheduler.ExecuteOnMainThread(() => m());

                if (Unity3D.Threads.OnMainThread())
                {
                    return m.RunSynchronously();
                }
                else
                {
                    var handle = new ManualResetEvent(false);
                    T result = default(T);
                    MainThreadComputationQueue
                    .Enqueue(() =>
                    {
                        result = m.RunSynchronously();
                        handle.Set();
                    });

                    handle.WaitOne();
                    return result;
                }
            };
        }

        [System.Obsolete("use StartOnMainThread", false)]
        public static Unit StartOnMainthread<T>(this Async<T> m)
        {
            return StartOnMainThread(m);
        }

        public static Unit StartOnMainThread<T>(this Async<T> m)
        {
            Scheduler.StartOnMainThread(m.IgnoreAction());
            return Unit.Default;
        }

        public static Action IgnoreAction<T>(this Async<T> m)
        {
            return () =>
            {
                m.RunSynchronously();
            };
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace Wooga.Foundation.Collections.Concurrent
{
    public class ConcurrentSet<T> : ICollection<T>
    {
        private readonly ReaderWriterLockSlim rwLock = new ReaderWriterLockSlim();
        private readonly HashSet<T> Set = new HashSet<T>();

        public ConcurrentSet()
        {
            
        }

        public ConcurrentSet(IEnumerable<T> enumerable)
        {
            foreach (var e in enumerable)
            {
                Set.Add(e);
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            try
            {
                rwLock.EnterWriteLock();
                return new HashSet<T>(Set).GetEnumerator();
            }
            finally
            {
                rwLock.ExitWriteLock();
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public void Add(T item)
        {
            try
            {
                rwLock.EnterWriteLock();
                Set.Add(item);
            }
            finally
            {
                rwLock.ExitWriteLock();
            }
        }

        public void Clear()
        {
            try
            {
                rwLock.EnterWriteLock();
                Set.Clear();
            }
            finally
            {
                rwLock.ExitWriteLock();
            }
        }

        public bool Contains(T item)
        {
            try
            {
                rwLock.EnterReadLock();
                return Set.Contains(item);
            }
            finally
            {
                rwLock.ExitReadLock();
            }
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            try
            {
                rwLock.EnterReadLock();
                Set.CopyTo(array, arrayIndex);
            }
            finally
            {
                rwLock.ExitReadLock();
            }
        }

        public bool Remove(T item)
        {
            try
            {
                rwLock.EnterWriteLock();
                return Set.Remove(item);
            }
            finally
            {
                rwLock.ExitWriteLock();
            }
        }

        public int Count
        {
            get
            {
                try
                {
                    rwLock.EnterReadLock();
                    return Set.Count;
                }
                finally
                {
                    rwLock.ExitReadLock();
                }
            }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }
    }
}

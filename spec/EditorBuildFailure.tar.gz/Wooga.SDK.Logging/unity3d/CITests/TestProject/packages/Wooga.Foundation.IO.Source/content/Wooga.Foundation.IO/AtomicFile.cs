﻿using System;
using System.IO;

namespace Wooga.Foundation.IO
{
    public static class AtomicFile
    {
        public const string TEMP_FILE_EXTENSION = "._tt";
        public const string NEW_FILE_EXTENSION = "._nn";

        public static void WriteAllTextAtomic(string fullPath, string text)
        {
            WriteDataAtomic(fullPath, (newPath) => File.WriteAllText(newPath, text));
        }

        public static void WriteAllBytesAtomic(string fullPath, byte[] data)
        {
            WriteDataAtomic(fullPath, (newPath) => File.WriteAllBytes(newPath, data));
        }

        public static void WriteDataAtomic(string fullPath, Action<string> writeDataCallback)
        {
            AssertLegalPath(fullPath);
            RevertFailedSaveIfNeeded(fullPath);
            CreateDirectoryForFile(fullPath);

            var newPath = GetNewFilePath(fullPath);
            var tempPath = GetTempFilePath(fullPath);

            writeDataCallback(newPath);

            if (File.Exists(fullPath)) File.Move(fullPath, tempPath);
            File.Move(newPath, fullPath);
            if (File.Exists(tempPath)) File.Delete(tempPath);
        }

        public static bool ExistsAndRecoverFromAtomicWrite(string path)
        {
            RevertFailedSaveIfNeeded(path);
            return File.Exists(path);
        }

        private static void RevertFailedSaveIfNeeded(string originalPath)
        {
            string newPath = GetNewFilePath(originalPath);
            string tempPath = GetTempFilePath(originalPath);
            bool originalExists = File.Exists(originalPath);
            bool newExists = File.Exists(newPath);
            bool tempExists = File.Exists(tempPath);

            if (!originalExists && tempExists && newExists) // recover after step 3. (see above)
            {
                File.Move(tempPath, originalPath);
                File.Delete(newPath);
            }
            else if (originalExists && tempExists && !newExists) // recover after step 4. (see above)
            {
                File.Delete(tempPath);
            }
            else if (newExists) // all other cases
            {
                File.Delete(newPath);
            }
        }

        private static void AssertLegalPath(string fullPath)
        {
            if (fullPath.EndsWith(TEMP_FILE_EXTENSION) || fullPath.EndsWith(NEW_FILE_EXTENSION))
            {
                throw new ArgumentException(
                    "The saved file cannot end in '"
                    + TEMP_FILE_EXTENSION
                    + "' or '"
                    + NEW_FILE_EXTENSION
                    + "'");
            }
        }

        private static void CreateDirectoryForFile(string fullPath)
        {
            var directoryPath = Path.GetDirectoryName(fullPath);
            if (!string.IsNullOrEmpty(directoryPath) && !Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
        }

        private static string GetTempFilePath(string fullPath)
        {
            var path = fullPath + TEMP_FILE_EXTENSION;
            return path;
        }


        private static string GetNewFilePath(string fullPath)
        {
            var path = fullPath + NEW_FILE_EXTENSION;
            return path;
        }
    }
}
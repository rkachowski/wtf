﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using Wooga.Foundation.Collections.Concurrent;
using Wooga.Lambda.Data;
using Wooga.Lambda.Control.Concurrent;
using Wooga.Lambda.Control.Monad;
using Wooga.Lambda.Storage;

namespace Wooga.Foundation.IO
{
    public class UniqueFileProducer : Producer<IEnumerable<byte>, IEnumerable<byte>>
    {
        static ConcurrentSet<string> OfLocations(IEnumerable<string> locations)
        {
            return new ConcurrentSet<string>(locations.Select(l => l));
        }

        private readonly FileSystem HDD;
        private readonly string Dir;
        private readonly ConcurrentSet<string> LocationsBeingConsumed = new ConcurrentSet<string>();
        private ConcurrentSet<string> LocationsBeingAvailable;
 
        public UniqueFileProducer(FileSystem hdd, string dir)
        {
            HDD = hdd;
            Dir = dir;

            LocationsBeingAvailable = InitializeAvailableLocations();
        }

        private ConcurrentSet<string> InitializeAvailableLocations()
        {
            var locations = HDD.GetDirAsync(Dir).RunSynchronously();
            return OfLocations(locations.Files);
        }
        
        public Async<Unit> Produce(IEnumerable<byte> input)
        {
            return () =>
            {
                var uniqueName = Guid.NewGuid() + ".fqtmp";
                var location = Path.Combine(Dir, uniqueName);
                HDD.WriteFileAsync(location, input).RunSynchronously();
                lock (HDD)
                {
                    LocationsBeingAvailable.Add(uniqueName);
                }
                return Unit.Default;
            };
        }

        private int Count()
        {
            lock (HDD)
            {
                return LocationsBeingAvailable.Count;
            }
        }

        public bool HasMore()
        {
            return Count() > 0;
        }

        public bool IsBeingConsumed()
        {
            lock (HDD)
            {
                return LocationsBeingConsumed.Count > 0;
            }
        }

        public Async<Maybe<TConsumed>> Consume<TConsumed>(Consumer<IEnumerable<byte>, TConsumed> consumer)
        {
            return () =>
            {
                var fileName = Maybe.Nothing<string>();
                lock (HDD)
                {
                    if (LocationsBeingAvailable.Count > 0)
                    {
                        var first = LocationsBeingAvailable.First();
                        LocationsBeingConsumed.Add(first);
                        LocationsBeingAvailable.Remove(first);
                        fileName = Maybe.Just(first);
                    }
                }
                return fileName.Bind<string, TConsumed>(name =>
                {
                    try
                    {
                        var location = Path.Combine(Dir, name);
                        var file = HDD.ReadFileAsync(location).RunSynchronously();
                        var result = consumer(file).RunSynchronously();
                        if (result.IsJust())
                        {
                            HDD.RmFileAsync(location).RunSynchronously();
                        }
                        lock (HDD)
                        {
                            if (result.IsNothing())
                            {
                                LocationsBeingAvailable.Add(name); 
                            }
                            LocationsBeingConsumed.Remove(name);
                        }
                        return result;
                    }
                    catch (FileNotFoundException)
                    {
                        lock (HDD)
                        {
                            LocationsBeingConsumed.Remove(name);
                        }
                        return Maybe.Nothing<TConsumed>();
                    }
                    catch (Exception)
                    {
                        lock (HDD)
                        {
                            LocationsBeingConsumed.Remove(name);
                            LocationsBeingAvailable.Add(name);
                        }
                        return Maybe.Nothing<TConsumed>();
                    }
                });
            };
        }
    }
}

﻿using System.Threading;

namespace Wooga.ThreadSafe
{
    public static class ThreadExtensions
    {
        public static bool IsMainThread(this Thread t)
        {
            return t.Equals(Unity3D.Threads.MainThread);
        }
    }
}
﻿using System;

namespace Wooga.ThreadSafe
{
    public static class Time
    {
        private static readonly DateTime JANUARY_FIRST_1970 = new DateTime(1970, 1, 1);
        private static readonly object Lock = new object();

        public static DateTime Now()
        {
            DateTime now;

            lock (Lock)
            {
                now = DateTime.Now;
            }

            return now;
        }


        public static DateTime UtcNow()
        {
            return Now().ToUniversalTime();
        }

        public static int EpochTime()
        {
            return (int)UtcNow().Subtract(JANUARY_FIRST_1970).TotalSeconds;
        }

        public static int EpochTime(DateTime time)
        {
            return (int)time.Subtract(JANUARY_FIRST_1970).TotalSeconds;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using System.Threading;

namespace Wooga.ThreadSafe
{
    public static class Unity3D
    {
        private static MainThreadComputationQueue _dispatcher;

        public static void Init()
        {
            if (Threads.MainThread != null)
            {
                return;
            }

            Paths.PersistentDataPath = Application.persistentDataPath;
            Threads.MainThread = Thread.CurrentThread;

#if UNITY_ANDROID && !UNITY_EDITOR
            AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");

            Paths.ApplicationDataPath = jo.Call<AndroidJavaObject>("getApplicationInfo").Get<string>("dataDir")+"/files";
#else
            Paths.ApplicationDataPath = Paths.PersistentDataPath;
#endif
            AttachMainThreadComputationQueue();
        }

        public static void AttachMainThreadComputationQueue()
        {
            if (!_dispatcher)
            {
                _dispatcher = new GameObject(typeof(MainThreadComputationQueue).Name).AddComponent<MainThreadComputationQueue>();
                UnityEngine.Object.DontDestroyOnLoad(_dispatcher);
            }
        }

        public static class Paths
        {
            public static string PersistentDataPath
            {
                get; internal set;
            }

            public static string ApplicationDataPath
            {
                get; internal set;
            }
        }

        public static class Threads
        {
            public static Thread MainThread
            {
                get; set;
            }

            public static bool OnMainThread()
            {
                return Thread.CurrentThread.IsMainThread();
            }

            
        }

        public static class Connectivity
        {
            public static ConnectivityInfo Status
            {
                get; set;
            }
        }
    }

    public struct ConnectivityInfo
    {
        public DateTime CreationUtcDateTime;

        public bool HasConnectivity;

        public ConnectivityInfo(bool HasConnectivity, DateTime CreationUtcDateTime)
        {
            this.HasConnectivity = HasConnectivity;
            this.CreationUtcDateTime = CreationUtcDateTime;
        }
    }

    public static class Scheduler
    {
        public delegate void AsyncComputationExceptionEventHandler(Exception e);
        public static event AsyncComputationExceptionEventHandler AsyncComputationExceptionEvent;

        public static void DispatchException(Exception e)
        {
            if (AsyncComputationExceptionEvent != null)
            {
                AsyncComputationExceptionEvent(e);
            }
            else
            {
                throw e;
            }
        }

        public static T ExecuteOnMainThread<T>(this Func<T> m)
        {
            if (Unity3D.Threads.OnMainThread())
            {
                return m();
            }
            else
            {
                var handle = new ManualResetEvent(false);
                T result = default(T);
                MainThreadComputationQueue
                .Enqueue(() =>
                {
                    result = m();
                    handle.Set();
                });

                handle.WaitOne();
                return result;
            }
        }

        public static void ExecuteOnMainThread(this Action m)
        {
            if (Unity3D.Threads.OnMainThread())
            {
                m();
            }
            else
            {
                var handle = new ManualResetEvent(false);
                MainThreadComputationQueue
                .Enqueue(() =>
                {
                    m();
                    handle.Set();
                });

                handle.WaitOne();
            }
        }

        public static void StartOnMainThread(this Action m)
        {
            MainThreadComputationQueue.Enqueue(m);
        }

        public static void StartOnWorkerThread(this Action m)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    m();
                }
                catch (Exception e)
                {
                    DispatchException(e);
                }
            });
        }

        public static void StartOnWorkerThread<T>(this Func<T> m)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    m();
                }
                catch (Exception e)
                {
                    DispatchException(e);
                }
            });
        }
    }

    public class MainThreadComputationQueue : MonoBehaviour
    {
        public static MainThreadComputationQueue Shared;

        private static readonly Queue<Action> Inbox = new Queue<Action>();

        public static void Enqueue(Action a)
        {
            lock (Inbox)
            {
                Inbox.Enqueue(a);
            }
        }

        public void Start()
        {
            Shared = this;
        }

        public void Update()
        {
            Action[] asyncs = null;
            lock (Inbox)
            {
                if (Inbox.Count > 0)
                {
                    asyncs = Inbox.ToArray();
                    Inbox.Clear();
                }
            }
            if (asyncs != null)
            {
                foreach (var async in asyncs)
                {
                    async();
                }
            }
        }
    }
}

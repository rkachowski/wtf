
# Unity ThreadSafe [![Build Status](https://magnum.travis-ci.com/wooga/wdk-unity-ThreadSafe.svg?token=5jb3FABjFj3XsUQNgrf4&branch=master)](https://magnum.travis-ci.com/wooga/wdk-unity-ThreadSafe)

Tools to make the unity mono library threadsafe

[ApiDoc](http://ci.sdk.wooga.com:8080/job/wdk-unity-ThreadSafe/ws/documentation/index.html)


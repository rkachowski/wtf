iusing UnityEngine;
using UnityEditor;
using System.Collections;

public class Example : EditorWindow
{
	void OnGUI () {
		// The actual window code goes here
	   }
}


hi, i am some random tokens which should cause a failure in the editor assembly build phase
